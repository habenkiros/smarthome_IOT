import { StyleSheet } from 'react-native'
import React, { useLayoutEffect } from 'react'
import { Box, Text, Button, TextField, Screen, HeaderLeftButton } from 'components'
import { color } from 'utils'
import { useDispatch, useSelector } from 'react-redux'
import { Formik } from 'formik';
import * as Yup from 'yup';
import { loginRequest } from '../store'

const UpdatePasswordSchema = Yup.object().shape({
  password: Yup.string().email().label("password").required(),
  confirm_password: Yup.string().label("Confirm password").required(),
});

const UpdatePassword = ({ navigation }) => {

  const { api } = useSelector(state => state.auth)
  const dispatch = useDispatch()

  useLayoutEffect(() => {
    navigation.setOptions({
      headerShown: true,
      headerShadowVisible: false,
      headerTitle: '',
      headerLeft: () => <HeaderLeftButton navigation={navigation} />
    });
  }, [])

  return (
    <Box style={styles.container}>
      <Screen preset='scroll' unsafe={true}>
        <Text variant='h4'>Update password</Text>
        <Formik
          initialValues={{ email: '', password: '' }}
          onSubmit={values => dispatch(loginRequest(values))}
          validationSchema={UpdatePasswordSchema}
        >
          {({ handleChange, handleBlur, handleSubmit, values, errors, touched }) => (
            <>
              <Box mt={10}>
                <Box mv={10}>
                  <TextField
                    label='New Password'
                    placeholder='Enter your new password'
                    onChangeText={handleChange('password')}
                    onBlur={handleBlur('password')}
                    value={values.password}
                    error={touched.password && errors.password}
                  />
                </Box>
                <Box mv={10}>
                  <TextField
                    label='Confirm new password'
                    placeholder='Confirm your new password'
                    onChangeText={handleChange('confirm_password')}
                    onBlur={handleBlur('confirm_password')}
                    value={values.confirm_password}
                    secureTextEntry={true}
                    error={touched.confirm_password && errors.confirm_password}
                  />
                </Box>
              </Box>
              <Button
                text="Update password"
                style={styles.button}
                onPress={handleSubmit}
                loading={api.loading}
              />
            </>
          )}
        </Formik>
      </Screen>
    </Box>
  )
}

export default UpdatePassword

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#ffff',
    flex: 1
  },
  button: {
    marginTop: 20
  },
  checkBoxContent: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 10,
  },
  subText: {
    position: 'absolute',
    right: 0,
    top: 5,
    color: color.palette.primary,
    fontWeight: '700'
  }
})
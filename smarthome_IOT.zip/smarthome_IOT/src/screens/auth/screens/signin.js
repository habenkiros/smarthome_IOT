import { ImageBackground, StyleSheet } from 'react-native'
import React from 'react'
import { Box, Text, Button, TextField, Screen } from 'components'
import SocialSignIn from '../components/social-signin'
import { color } from 'utils'
import { useDispatch, useSelector } from 'react-redux'
import { Formik } from 'formik';
import * as Yup from 'yup';
import { loginRequest } from '../store'

const SignInSchema = Yup.object().shape({
  email: Yup.string().email().label("Email").required(),
  password: Yup.string().label("Password").required(),
});

const SignIn = ({ navigation }) => {

  const { api } = useSelector(state => state.auth)
  const dispatch = useDispatch()

  return (
    <ImageBackground source={require("assets/images/auth-bg.png")} style={styles.imageBg}>
      <Box style={styles.container}>
        <Screen preset='scroll' backgroundColor='transparent'>
          <Text variant='h3' textAlign='center' color='white'>Login</Text>
          <Button variant='link' style={styles.subText} text='Sign up' onPress={() => navigation.navigate('SignUpScreen')} />
          <Formik
            initialValues={{ email: '', password: '' }}
            onSubmit={values => dispatch(loginRequest(values))}
            validationSchema={SignInSchema}
          >
            {({ handleChange, handleBlur, handleSubmit, values, errors, touched }) => (
              <>
                <Box mt={30}>
                  <Box mv={10}>
                    <TextField
                      label='Email address'
                      placeholder='Enter your email address'
                      textColor='white'
                      onChangeText={handleChange('email')}
                      onBlur={handleBlur('email')}
                      value={values.email}
                      error={touched.email && errors.email}
                    />
                  </Box>
                  <Box mv={10}>
                    <TextField
                      label='Password'
                      placeholder='Enter your email address'
                      textColor='white'
                      onChangeText={handleChange('password')}
                      onBlur={handleBlur('password')}
                      value={values.password}
                      secureTextEntry={true}
                      error={touched.password && errors.password}
                    />
                  </Box>
                  <Box style={styles.checkBoxContent}>
                    <Button
                      text='Forgot Password?'
                      variant='link'
                      onPress={() => navigation.navigate('ForgotPassword')}
                    />
                  </Box>
                </Box>
                <Button
                  text="Login"
                  style={styles.button}
                  onPress={handleSubmit}
                  loading={api.loading}
                />
              </>
            )}
          </Formik>
          <SocialSignIn />
        </Screen>
      </Box>
    </ImageBackground>
  )
}

export default SignIn

const styles = StyleSheet.create({
  imageBg: {
    height: '100%',
    width: '100%',
    flex: 1,
  },
  container: {
    padding: 16,
    backgroundColor: 'rgba(39, 27, 7, 0.65)',
    flex: 1
  },
  button: {
    marginTop: 20
  },
  checkBoxContent: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 10,
  },
  subText: {
    position: 'absolute',
    right: 0,
    top: 5,
    color: color.palette.primary,
    fontWeight: '700'
  }
})
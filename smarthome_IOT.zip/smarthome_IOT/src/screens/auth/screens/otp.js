import React, { useLayoutEffect, useRef, useState } from 'react'
import { View, TextInput, ScrollView, StyleSheet } from 'react-native'
import { useSelector, useDispatch } from 'react-redux'
import { unwrapResult } from '@reduxjs/toolkit'
import { useFocusEffect } from '@react-navigation/core'
import { Box, Screen, Button, Text, HeaderLeftButton } from 'components'
import { verifyResetToken } from '../store'

const OtpScreen = ({ navigation }) => {
  const otpNumber1Ref = useRef(null);
  const otpNumber2Ref = useRef(null);
  const otpNumber3Ref = useRef(null);
  const otpNumber4Ref = useRef(null);
  const otpNumber5Ref = useRef(null);
  const otpNumber6Ref = useRef(null);

  const { api, resetEmail } = useSelector(state => state.auth)
  const dispatch = useDispatch()

  const [values, setValues] = useState({
    otp1: '',
    otp2: '',
    otp3: '',
    otp4: '',
    otp5: '',
    otp6: '',

  })

  useLayoutEffect(() => {
    navigation.setOptions({
      headerShown: true,
      headerShadowVisible: false,
      headerTitle: '',
      headerLeft: () => <HeaderLeftButton navigation={navigation} />
    });
  }, [])

  useFocusEffect(
    React.useCallback(() => {
    }, [])
  );

  const setOtpValue = (label, value) => {
    setValues({
      ...values,
      [label]: value
    })
  }

  const verify = () => {
    const { otp1, otp2, otp3, otp4, otp5, otp6 } = values
    dispatch(verifyResetToken({
      email: resetEmail,
      token: otp1 + otp2 + otp3 + otp4 + otp5 + otp6
    }))
      .then(unwrapResult)
      .then(() => {
        navigation.navigate("ConfirmReset")
      })
  }

  return (
    <Box style={styles.container}>
      <Screen unsafe={true}>
        <Text variant='h4' style={{ marginBottom: 30, marginTop: 10 }}>Enter token sent to email</Text>
        <Text>Enter the 6-digit token</Text>
        <View style={styles.otpContent}>
          <TextInput
            style={styles.loginInput}
            maxLength={1}
            ref={otpNumber1Ref}
            value={values.otp1}
            onChangeText={(input) => {
              setOtpValue("otp1", input);
              if (input) {
                otpNumber2Ref.current?.focus();
              }
            }}
            keyboardType="number-pad"
          />
          <TextInput
            style={styles.loginInput}
            maxLength={1}
            ref={otpNumber2Ref}
            value={values.otp2}
            onChangeText={(input) => {
              if (input.length > 0) {
                setOtpValue("otp2", input);
                if (input) {
                  otpNumber3Ref.current?.focus();
                }
              } else {
                setOtpValue("otp2", input);
                otpNumber1Ref.current?.focus();

              }
            }}
            keyboardType="number-pad"
          />
          <TextInput
            style={styles.loginInput}
            maxLength={1}
            ref={otpNumber3Ref}
            value={values.otp3}
            onChangeText={(input) => {
              if (input.length > 0) {
                setOtpValue("otp3", input);
                if (input) {
                  otpNumber4Ref.current?.focus();
                }
              } else {
                setOtpValue("otp3", input);
                otpNumber2Ref.current?.focus();

              }
            }}
            keyboardType="number-pad"
          />
          <TextInput
            style={styles.loginInput}
            maxLength={1}
            ref={otpNumber4Ref}
            value={values.otp4}
            onChangeText={(input) => {
              if (input.length > 0) {
                setOtpValue("otp4", input);
                if (input) {
                  otpNumber5Ref.current?.focus();
                }
              } else {
                setOtpValue("otp4", input);
                otpNumber3Ref.current?.focus();

              }
            }}
            keyboardType="number-pad"
          />
          <TextInput
            style={styles.loginInput}
            maxLength={1}
            ref={otpNumber5Ref}
            value={values.otp5}
            onChangeText={(input) => {
              if (input.length > 0) {
                setOtpValue("otp5", input);
                if (input) {
                  otpNumber6Ref.current?.focus();
                }
              } else {
                setOtpValue("otp5", input);
                otpNumber4Ref.current?.focus();

              }
            }}
            keyboardType="number-pad"
          />
          <TextInput
            style={styles.loginInput}
            maxLength={1}
            ref={otpNumber6Ref}
            value={values.otp6}
            onChangeText={(input) => {
              if (input.length > 0) {
                setOtpValue("otp6", input);
              } else {
                setOtpValue("otp6", input);
                otpNumber5Ref.current?.focus();

              }
            }}
            keyboardType="number-pad"
          />
        </View>
        <Button text='Continue' onPress={verify} />
        <Button variant='link' text='Resend token' style={{ marginTop: 30 }} />
      </Screen>
    </Box>
  )
}

export default OtpScreen

export const styles = StyleSheet.create({
  container: {
    padding: 16,
    flex: 1,
    backgroundColor: '#fff'
  },
  otpContent: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 10,
    marginBottom: 30
  },
  loginInput: {
    // backgroundColor: '#F6F6F8',
    width: 50,
    height: 50,
    borderRadius: 10,
    textAlign: "center",
    borderWidth: 1,
    borderColor: '#1F1F1F'
  },
})

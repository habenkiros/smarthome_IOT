import { ImageBackground, StyleSheet } from 'react-native'
import React from 'react'
import { Box, Text, Button, TextField, Screen } from 'components'
import { color } from 'utils'
import { Formik } from 'formik';
import * as Yup from 'yup';
import { useDispatch, useSelector } from 'react-redux'
import { sendResetToken } from '../store';
import { unwrapResult } from '@reduxjs/toolkit';

const ForgotPasswordSchema = Yup.object().shape({
  email: Yup.string().email().label("Email").required(),
});

const ForgotPassword = ({ navigation }) => {

  const { api } = useSelector(state => state.auth)
  const dispatch = useDispatch()

  return (
    <ImageBackground source={require("assets/images/auth-bg.png")} style={styles.imageBg}>
      <Box style={styles.container}>
        <Screen preset='scroll' backgroundColor='transparent'>
          <Text variant='h3' textAlign='center' color='white'>Forgot Password</Text>
          <Button variant='link' style={styles.subText} text='Login' onPress={() => navigation.navigate('SignInScreen')} />
          <Formik
            initialValues={{ email: '' }}
            onSubmit={values =>
              dispatch(sendResetToken(values))
                .then(unwrapResult)
                .then(() => navigation.navigate('OtpScreen'))
            }
            validationSchema={ForgotPasswordSchema}
          >
            {({ handleChange, handleBlur, handleSubmit, values, errors, touched }) => (
              <>
                <Box mt={30}>
                  <Box mv={10}>
                    <TextField
                      label='Email address'
                      placeholder='Enter your email address'
                      textColor='white'
                      onChangeText={handleChange('email')}
                      onBlur={handleBlur('email')}
                      value={values.email}
                      error={touched.email && errors.email}
                    />
                  </Box>
                </Box>
                <Button
                  text="Reset Password"
                  style={styles.button}
                  onPress={handleSubmit}
                  loading={api.loading}
                />
              </>
            )}
          </Formik>
          <Text
            variant='text'
            textAlign='center'
            color='white'
          >We'll send you a token via this email address.</Text>
          <Text
            variant='text'
            textAlign='center'
            color='error'
          >{api?.error}</Text>
        </Screen>
      </Box>
    </ImageBackground>
  )
}

export default ForgotPassword

const styles = StyleSheet.create({
  imageBg: {
    height: '100%',
    width: '100%',
    flex: 1,
  },
  container: {
    padding: 16,
    backgroundColor: 'rgba(39, 27, 7, 0.65)',
    flex: 1
  },
  button: {
    marginVertical: 20
  },
  subText: {
    position: 'absolute',
    right: 0,
    top: 5,
    color: color.palette.primary,
    fontWeight: '700'
  }
})
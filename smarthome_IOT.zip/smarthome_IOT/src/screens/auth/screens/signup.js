import { ImageBackground, StyleSheet } from 'react-native'
import { CheckBox } from 'react-native-elements'
import React from 'react'
import { Box, Text, Button, TextField, Screen } from 'components'
import SocialSignIn from '../components/social-signin'
import { color } from 'utils'
import { Formik } from 'formik';
import * as Yup from 'yup';
import { useDispatch, useSelector } from 'react-redux'
import { signupRequest } from '../store'

const SignupSchema = Yup.object().shape({
  email: Yup.string().email().label("Email").required(),
  password: Yup.string().label("Password").required(),
  confirm_password: Yup.string().label("Confirm Password").required(),
});

const SignUp = ({ navigation }) => {

  const { api } = useSelector(state => state.auth)
  const dispatch = useDispatch()

  return (
    <ImageBackground source={require("assets/images/auth-bg.png")} style={styles.imageBg}>
      <Box style={styles.container}>
        <Screen preset='scroll' backgroundColor='transparent'>
          <Text variant='h3' textAlign='center' color='white'>Sign up</Text>
          <Button variant='link' style={styles.subText} text='Login' onPress={() => navigation.navigate('SignInScreen')} />
          <Formik
            initialValues={{ email: '', password: '', confirm_password: '' }}
            onSubmit={values => dispatch(signupRequest(values))}
            validationSchema={SignupSchema}
          >
            {({ handleChange, handleBlur, handleSubmit, values, errors, touched }) => (
              <>
                <Box mt={30}>
                  <Box mv={10}>
                    <TextField
                      label='Email address'
                      placeholder='Enter your email address'
                      textColor='white'
                      onChangeText={handleChange('email')}
                      onBlur={handleBlur('email')}
                      value={values.email}
                      error={touched.email && errors.email}
                    />
                  </Box>
                  <Box mv={10}>
                    <TextField
                      label='Password'
                      placeholder='Enter your password'
                      textColor='white'
                      onChangeText={handleChange('password')}
                      onBlur={handleBlur('password')}
                      value={values.password}
                      secureTextEntry={true}
                      error={touched.password && errors.password}
                    />
                  </Box>
                  <Box mv={10}>
                    <TextField
                      label='Confirm Password'
                      placeholder='Confirm your password'
                      textColor='white'
                      onChangeText={handleChange('confirm_password')}
                      onBlur={handleBlur('confirm_password')}
                      value={values.confirm_password}
                      secureTextEntry={true}
                      error={touched.password && errors.password}

                    />
                  </Box>
                  <Box style={styles.checkBoxContent}>
                    <CheckBox />
                    <Text style={{ flex: 1 }} color="white">
                      I have read <Button variant='link' text="Terms and Conditions" /> and <Button variant='link' text="Privacy Policy." />
                    </Text>
                  </Box>
                </Box>
                <Button
                  text="Sign Up"
                  style={styles.button} onPress={handleSubmit}
                  loading={api.loading}
                />
              </>
            )}
          </Formik>
          <SocialSignIn />
        </Screen>
      </Box>
    </ImageBackground>
  )
}

export default SignUp

const styles = StyleSheet.create({
  imageBg: {
    height: '100%',
    width: '100%',
    flex: 1,
  },
  container: {
    padding: 16,
    backgroundColor: 'rgba(39, 27, 7, 0.65)',
    flex: 1
  },
  screen: {
    padding: 16,
  },
  button: {
    marginTop: 20
  },
  checkBoxContent: {
    flexDirection: 'row',
    marginTop: 10,
  },
  hrContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  hr: {
    borderTopWidth: 1,
    width: '45%',
    borderColor: '#F3F5F966'
  },
  subText: {
    position: 'absolute',
    right: 0,
    top: 5,
    color: color.palette.primary,
    fontWeight: '700'
  }
})
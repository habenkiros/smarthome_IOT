import { StyleSheet, Image } from 'react-native'
import React from 'react'
import { GoogleSignin } from '@react-native-google-signin/google-signin';
import { LoginManager, AccessToken } from "react-native-fbsdk-next"
import { Box, Button, Text } from 'components'
import { facebookLogin, googleLogin } from '../store';
import { useDispatch } from 'react-redux';

export const onGoogleConnect = async dispatch => {
  try {
    await GoogleSignin.hasPlayServices()
    await GoogleSignin.signIn()
    const tokens = await GoogleSignin.getTokens()
    dispatch(googleLogin({
      access_token: tokens.accessToken,
      code: tokens.idToken
    }))
  } catch (err) {
    console.log(err)
  }
}

export const onFacebookConnect = async dispatch => {
  LoginManager.logInWithPermissions(["public_profile", "email"]).then(
    function (result) {
      if (result.isCancelled) {
        console.log("Login cancelled");
      } else {
        console.log(
          "Login success with permissions: " +
          result.grantedPermissions.toString()
        );
        AccessToken.getCurrentAccessToken().then(
          (data) => {
            dispatch(facebookLogin({
              access_token: data.accessToken,
              code: data.userID
            }))
          }
        )
      }
    },
    function (error) {
      console.log("Login fail with error: " + error);
    }
  );
}

const SocialSignIn = () => {

  const dispatch = useDispatch()

  return (
    <Box mt={20}>
      <Box style={styles.hrContent}>
        <Box style={styles.hr} />
        <Text color='white'>Or</Text>
        <Box style={styles.hr} />
      </Box>
      <Button
        variant='outline'
        text="Login with Google"
        style={styles.button}
        textColor='white'
        icon={<Image source={require('assets/images/google.png')} style={styles.icon} />}
        onPress={() => onGoogleConnect(dispatch)}
      />
      <Button
        variant='outline'
        text="Login with Apple"
        style={styles.button}
        textColor='white'
        icon={<Image source={require('assets/images/apple.png')} style={styles.icon} />}
      />
      <Button
        variant='outline'
        text="Login with Facebook"
        style={styles.button}
        textColor='white'
        icon={<Image source={require('assets/images/fb.png')} style={styles.icon} />}
        onPress={() => onFacebookConnect(dispatch)}
      />
    </Box>
  )
}

export default SocialSignIn

const styles = StyleSheet.create({
  hrContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20
  },
  hr: {
    borderTopWidth: 1,
    width: '45%',
    borderColor: '#F3F5F966'
  },
  button: {
    marginBottom: 15
  },
  icon: {
    marginRight: 10
  }
})
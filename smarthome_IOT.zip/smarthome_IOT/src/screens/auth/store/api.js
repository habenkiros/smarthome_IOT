import authAPI from 'utils/httpClient'

function apiLoginRequest(payload) {
  return authAPI.post(`/rest-auth/login/`, payload, {
    headers: { Authorization: "" }
  })
}

function apiSignupRequest(payload) {
  return authAPI.post(`/rest-auth/registration/`, payload, {
    headers: { Authorization: "" }
  })
}

function apiLogoutRequest(payload) {
  return authAPI.post(`/rest-auth/logout/`, null, {
    headers: { Authorization: `Token ${payload.token}` }
  })
}

function apiAuthUserRequest(payload) {
  return authAPI.get(`/rest-auth/user/`, null, {
    headers: { Authorization: `Token ${payload.token}` }
  })
}

function apiSendTokenRequest(payload) {
  return authAPI.post(`/api/password_reset/`, payload, {
    headers: { Authorization: "" }
  })
}

function apiVerifyTokenRequest(payload) {
  return authAPI.post(`/api/password-reset/validate_token/`, payload, {
    headers: { Authorization: "" }
  })
}

function apiResetPasswordRequest(payload) {
  return authAPI.post(`/api/v1/password-reset/set-password/`, payload, {
    headers: { Authorization: "" }
  })
}

function apiFacebookLogin(payload) {
  return authAPI.post(`/api/auth/facebook/`, payload, {
    headers: { Authorization: "" }
  })
}

function apiGoogleLogin(payload) {
  return authAPI.post(`/api/auth/google/`, payload, {
    headers: { Authorization: "" }
  })
}

function apiAppleLogin(payload) {
  return authAPI.post(`/modules/social-auth/apple/login/`, payload, {
    headers: { Authorization: "" }
  })
}

function apiGetUserProfile() {
  return authAPI.get(`/rest-auth/user/`)
}

function apiPostUserProfile(payload) {
  return authAPI.post(`/api/v1/user-profile/`, payload)
}

function apiUpdateUserProfile(payload) {
  return authAPI.patch(`/rest-auth/user/`, payload)
}

function apiChangePassword(payload) {
  return authAPI.put(`/api/v1/password-change/`, payload)
}

export const api = {
  apiLoginRequest,
  apiSignupRequest,
  apiLogoutRequest,
  apiResetPasswordRequest,
  apiAuthUserRequest,
  apiFacebookLogin,
  apiGoogleLogin,
  apiAppleLogin,
  apiSendTokenRequest,
  apiVerifyTokenRequest,
  apiGetUserProfile,
  apiPostUserProfile,
  apiChangePassword,
  apiUpdateUserProfile
}

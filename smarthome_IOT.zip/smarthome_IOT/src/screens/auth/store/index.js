import { createSlice, createAsyncThunk } from "@reduxjs/toolkit"
import { getServerError } from "utils/utils"
import AsyncStorage from '@react-native-async-storage/async-storage';
import { setAuthToken } from "utils/httpClient"
import { api } from "./api"

export const loginRequest = createAsyncThunk(
  "login/loginRequest",
  async (payload) => {
    try {
      const response = await api.apiLoginRequest(payload)
      AsyncStorage.setItem("@token", JSON.stringify(response.data.key))
      setAuthToken(response.data.key)
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const signupRequest = createAsyncThunk(
  "login/signupRequest",
  async payload => {
    try {
      const response = await api.apiSignupRequest(payload)
      AsyncStorage.setItem("@token", JSON.stringify(response.data.key))
      setAuthToken(response.data.key)
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const logoutRequest = createAsyncThunk(
  "login/logoutRequest",
  async payload => {
    AsyncStorage.removeItem("@token")
    setAuthToken("")
  }
)

export const getAuthUser = createAsyncThunk(
  "login/getAuthUser",
  async payload => {
    const response = await api.apiAuthUserRequest(payload)
    const { profile, ...rest } = response.data
    return {
      ...rest,
      ...profile
    }
  }
)
export const resetPassword = createAsyncThunk(
  "login/resetPassword",
  async payload => {
    try {
      const response = await api.apiResetPasswordRequest(payload)
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const sendResetToken = createAsyncThunk(
  "login/sendResetToken",
  async payload => {
    try {
      await api.apiSendTokenRequest(payload)
      return payload;
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const verifyResetToken = createAsyncThunk(
  "login/verifyResetToken",
  async payload => {
    try {
      await api.apiVerifyTokenRequest(payload)
      return payload;
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const facebookLogin = createAsyncThunk(
  "login/facebookLogin",
  async payload => {
    try {
      const response = await api.apiFacebookLogin(payload)
      AsyncStorage.setItem("@token", JSON.stringify(response.data.key))
      setAuthToken(response.data.key)
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const googleLogin = createAsyncThunk(
  "login/googleLogin",
  async payload => {
    try {
      const response = await api.apiGoogleLogin(payload)
      AsyncStorage.setItem("@token", JSON.stringify(response.data.key))
      setAuthToken(response.data.key)
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)
export const appleLogin = createAsyncThunk(
  "login/appleLogin",
  async payload => {
    try {
      const response = await api.apiAppleLogin(payload)
      AsyncStorage.setItem("@token", JSON.stringify(response.data.token))
      setAuthToken(response.data.token)
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const getUserProfile = createAsyncThunk(
  "login/getUserProfile",
  async () => {
    try {
      const response = await api.apiGetUserProfile()
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const postUserProfile = createAsyncThunk(
  "login/postUserProfile",
  async payload => {
    try {
      const response = await api.apiPostUserProfile(payload)
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const updateUserProfile = createAsyncThunk(
  "login/updateUserProfile",
  async payload => {
    try {
      const response = await api.apiUpdateUserProfile(payload)
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const changePassword = createAsyncThunk(
  "login/changePassword",
  async payload => {
    try {
      const response = await api.apiChangePassword(payload)
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const initialAuthState = {
  token: null,
  user: {},
  resetEmail: '',
  api: { loading: false, error: null },
  userUpdated: false
}
export const authSlice = createSlice({
  name: "auth",
  initialState: initialAuthState,
  reducers: {
    resetMessages: (state) => {
      state.api.error = null
    },
  },
  extraReducers: {
    [loginRequest.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [loginRequest.fulfilled]: (state, action) => {
      state.user = action.payload.user
      state.api.loading = false
    },
    [loginRequest.rejected]: (state, action) => {
      state.api.error = action.error
      state.api.loading = false
    },

    [signupRequest.pending]: state => {
      state.api.loading = true
      state.api.error = null
      state.token = null
    },
    [signupRequest.fulfilled]: (state, action) => {
      state.user = action.payload.user
      state.api.loading = false
    },
    [signupRequest.rejected]: (state, action) => {
      state.api.error = action.error
      state.api.loading = false
    },

    [logoutRequest.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [logoutRequest.fulfilled]: state => {
      return initialAuthState
    },
    [logoutRequest.rejected]: (state, action) => {
      state.api.error = action.error
      state.api.loading = false
    },
    [getAuthUser.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [getAuthUser.fulfilled]: (state, action) => {
      state.user = action.payload
      state.api.loading = false
      state.api.error = null
    },
    [getAuthUser.rejected]: (state, action) => {
      //state.api.error = action.error
      state.api.loading = false
    },

    [resetPassword.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [resetPassword.fulfilled]: (state, action) => {
      state.api.loading = false
      state.api.error = null
    },
    [resetPassword.rejected]: (state, action) => {
      state.api.error = action.error
      state.api.loading = false
    },

    [sendResetToken.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [sendResetToken.fulfilled]: (state, action) => {
      state.resetEmail = action.payload.email
      state.api.loading = false
      state.api.error = null
    },
    [sendResetToken.rejected]: (state, action) => {
      state.api.error = action.error.message
      state.api.loading = false
    },

    [verifyResetToken.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [verifyResetToken.fulfilled]: (state, action) => {
      state.api.loading = false
      state.api.error = null
    },
    [verifyResetToken.rejected]: (state, action) => {
      state.api.error = action.error
      state.api.loading = false
    },

    [facebookLogin.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [facebookLogin.fulfilled]: (state, action) => {
      state.user = action.payload.user
      state.api.loading = false
      state.api.error = null
    },
    [facebookLogin.rejected]: (state, action) => {
      state.api.error = action.error
      state.api.loading = false
    },
    [googleLogin.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [googleLogin.fulfilled]: (state, action) => {
      state.user = action.payload.user
      state.api.error = null
      state.api.loading = false
    },
    [googleLogin.rejected]: (state, action) => {
      state.api.error = action.error
      state.api.loading = false
    },
    [appleLogin.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [appleLogin.fulfilled]: (state, action) => {
      state.user = action.payload.user
      state.api.error = null
      state.api.loading = false
    },
    [appleLogin.rejected]: (state, action) => {
      state.api.error = action.error
      state.api.loading = false
    },
    [getUserProfile.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [getUserProfile.fulfilled]: (state, action) => {
      state.user = {
        ...state.user,
        ...action.payload
      }
      state.userUpdated = action.payload ? true : false
      state.api.error = null
      state.api.loading = false
    },
    [getUserProfile.rejected]: (state, action) => {
      state.api.error = action.error
      state.api.loading = false
    },
    [postUserProfile.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [postUserProfile.fulfilled]: (state, action) => {
      state.user = {
        ...state.user,
        ...action.payload
      },
        state.userUpdated = true
      state.api.error = null
      state.api.loading = false
    },
    [postUserProfile.rejected]: (state, action) => {
      state.api.error = action.error
      state.api.loading = false
    },

    [updateUserProfile.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [updateUserProfile.fulfilled]: (state, action) => {
      state.user = {
        ...state.user,
        ...action.payload
      }
      state.userUpdated = true
      state.api.error = null
      state.api.loading = false
    },
    [updateUserProfile.rejected]: (state, action) => {
      state.api.error = action.error
      state.api.loading = false
    },

    [changePassword.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [changePassword.fulfilled]: (state, action) => {
      state.api.error = null
      state.api.loading = false
    },
    [changePassword.rejected]: (state, action) => {
      state.api.error = action.error.message
      state.api.loading = false
    }
  }
})

export const { resetMessages } = authSlice.actions
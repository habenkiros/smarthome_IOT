import { StyleSheet, FlatList } from 'react-native'
import React, { useEffect, useRef } from 'react'
import Unit from '../components/unit'
import { useSelector, useDispatch } from 'react-redux'
import { getUnitsRequest, selectUnit } from '../store'
import { Box } from 'components'
import { deleteUnitRequest } from '../store'
import BottomSheet from '../components/bottomsheet'


const UnitList = ({ navigation }) => {
  const units = useSelector(state => state.dashboard.units)
  const bottomSheetRef = useRef(null);
  const selectedUnit = useSelector(state => state.dashboard.selectedUnit)
  const dispatch = useDispatch()

  useEffect(() => {
    dispatch(getUnitsRequest())
  }, [])

  return (
    <Box flex={1}>
      <FlatList
        data={units}
        renderItem={({ item }) => <Unit
          onClick={() => navigation.navigate('UnitViewScreen', { unit: item })}
          image={item.image}
          title={item.name}
          subText={item.address}
          openSheet={() => [dispatch(selectUnit(item)), bottomSheetRef.current.snapToIndex(0)]}
        />}
        keyExtractor={(item) => item.id}
        scrollEnabled={true}
        style={styles.container}
        showsVerticalScrollIndicator={false}
        onTouchStart={() => bottomSheetRef.current.close()}
      />
      <BottomSheet
        bottomSheetRef={bottomSheetRef}
        navigation={navigation}
        deleteHandler={() => dispatch(deleteUnitRequest(selectedUnit?.id))}
      />
    </Box>
  )
}

export default UnitList

const styles = StyleSheet.create({
  container: {
    padding: 16,
    // flex: 1,
    marginBottom: 20
  },
})
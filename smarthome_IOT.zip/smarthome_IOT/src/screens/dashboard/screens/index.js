import { StyleSheet } from 'react-native'
import React, { useLayoutEffect, useState } from 'react'
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import { Screen } from 'components'
import { color } from 'utils'
import RightButton from '../components/rightButton'
import Tabs from '../components/tabs'
import Calendar from './calendar'
import UnitList from './unit-list';
import { useDispatch } from 'react-redux';
import { selectUnit } from '../store';

const Tab = createMaterialTopTabNavigator();

const DashboardScreen = ({ navigation }) => {

  const [tab, setTab] = useState('UnitList')
  const dispatch = useDispatch();

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => <RightButton
        onAdd={() => [
          dispatch(selectUnit({})),
          navigation.navigate(tab === 'UnitList' ? 'AddUnitScreen' : 'AddBookingScreen'),
        ]}
      />
    })

  }, [tab])

  return (
    <>
      <Screen preset='fixed' unsafe={true}>
        <Tab.Navigator
          tabBar={(props) => <Tabs
            {...props}
            onTabChange={(selectedTab) => setTab(selectedTab)}
          />}
        >
          <Tab.Screen
            name="UnitList"
            component={UnitList}
            options={{
              tabBarLabel: 'Units',
              tabBarIcon: (focused) => <FontAwesome name='envelope-open-o' color={focused ? '#B2946C' : '#898989'} size={20} style={{ marginRight: 15 }} />
            }}
          />
          <Tab.Screen
            name="Calendar"
            component={Calendar}
            options={{
              tabBarLabel: 'Calendar',
              tabBarIcon: (focused) => <FontAwesome name='calendar-o' color={focused ? '#B2946C' : '#898989'} size={20} style={{ marginRight: 15 }} />
            }}
          />
        </Tab.Navigator>
      </Screen>
    </>
  )
}

export default DashboardScreen

const styles = StyleSheet.create({
  imageBg: {
    height: '100%',
    width: '100%',
    flex: 1,
  },
  button: {
    marginVertical: 20
  },
  subText: {
    position: 'absolute',
    right: 0,
    color: color.palette.primary,
    fontWeight: '700'
  }
})
import { StyleSheet, View, Platform } from 'react-native'
import React, { useEffect, useState } from 'react'
import { Calendar as RNCalendar } from 'react-native-calendars';
import RNPicker from 'react-native-dropdown-picker'
import { Box, Text, Screen } from 'components';
import { typography } from 'utils';
import moment from 'moment'
import BookedSlot from '../components/booked-slot';
import { useDispatch, useSelector } from 'react-redux';
import { getBookings, deleteBooking } from '../store';
import CalendarWeeklyView from '../components/calendar-weekly';
import CalendarDailyView from '../components/daily-weekly';

const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];


const Calendar = ({ navigation }) => {
  const [open, setOpen] = useState(false);
  const [calendarView, setCalendarView] = useState('monthly');
  const [markedDates, setMarkedDates] = useState({})
  const bookings = useSelector(state => state.dashboard.bookings)
  const dispatch = useDispatch()

  useEffect(() => {
    dispatch(getBookings())
  }, [])

  useEffect(() => {
    const dates = {}
    bookings.map(b => {
      let arrival = moment(b.arrival)
      let departure = moment(b.departure)
      let duration = Math.round(moment.duration(departure.diff(arrival)).asDays());
      let index = 0
      do {
        dates[moment(b.arrival).add(index, 'days').format('YYYY-MM-DD')] = {
          startingDay: index === 0,
          endingDay: index === duration - 1,
          color: '#FFECD2',
          customContainerStyle: {
            borderRadius: 8,
          }
        }
        index += 1;
      } while (index < duration)
    })
    setMarkedDates(dates)
  }, [bookings])

  return (
    <Box flex={1}>
      <Screen preset='scroll' unsafe={true}>
        <View style={[styles.pickerContainer, Platform.OS === 'android' && open && { minHeight: 300, marginBottom: -250, }]}>
          <RNPicker
            items={[
              { value: 'monthly', label: 'Monthly' },
              { value: 'weekly', label: 'Weekly' },
              { value: 'daily', label: 'Daily' },
            ]}
            open={open}
            value={calendarView}
            setOpen={setOpen}
            setValue={setCalendarView}
            style={{
              borderWidth: 0,
              width: '45%'
            }}
            dropDownContainerStyle={{
              borderWidth: 0,
              width: '45%',
            }}
            labelStyle={{
              textAlign: 'right'
            }}
            listItemLabelStyle={{
              textAlign: 'right',
              marginRight: 30
            }}
            showTickIcon={false}
          />
        </View>
        <Box style={styles.calendarContainer}>
          {calendarView === 'daily' && <CalendarDailyView markedDates={markedDates} />}
          {calendarView === 'weekly' && <CalendarWeeklyView markedDates={markedDates} />}
          {
            calendarView === 'monthly' &&
            <RNCalendar
              style={{ marginTop: -10 }}
              current={new Date()}
              renderHeader={(date) => <Text variant='strong'>
                {months[date.getMonth()]} {date.getFullYear()}
              </Text>}
              theme={{
                arrowColor: '#828282',
                textDayFontFamily: typography.regular_400,
                textMonthFontFamily: typography.bold_700,
              }}
              markingType={'period'}
              markedDates={markedDates}
            />
          }
        </Box>
        <Box flexDirection="row" mt={20} ph={16}>
          <Box flexDirection="row" alignItems="center"><Box style={styles.daysBooked} /><Text>Days booked</Text></Box>
          <Box ml={20} flexDirection="row" alignItems="center"><Box style={styles.daysAvailable} /><Text>Days available</Text></Box>
        </Box>
        <Box mt={20} mb={25} ph={16}>
          <Text variant='h5'>Booked slots</Text>
          {
            bookings.map(booking => <BookedSlot
              booking={booking}
              onDelete={() => dispatch(deleteBooking(booking.id))}
              onEdit={() => navigation.navigate('AddBookingScreen', { booking })}
            />)
          }
        </Box>
      </Screen>
    </Box>
  )
}

export default Calendar

const styles = StyleSheet.create({
  calendar: {
    paddingBottom: 15
  },
  daysBooked: {
    backgroundColor: '#FFECD2',
    height: 24,
    width: 24,
    borderRadius: 8,
    marginRight: 10,
    borderWidth: 1,
    borderColor: '#C3C6B8'
  },
  daysAvailable: {
    backgroundColor: '#ffff',
    height: 24,
    width: 24,
    borderRadius: 8,
    marginRight: 10,
    borderWidth: 1,
    borderColor: '#C3C6B8'
  },
  pickerContainer: {
    zIndex: 100,
    elevation: 10,
    paddingHorizontal: 16,
    alignSelf: 'flex-end',
  },
  calendarContainer: {
    borderRadius: 18,
    marginVertical: Platform.OS === 'android' ? -10 : 10,
    shadowColor: '#171717',
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    backgroundColor: 'white',
    marginHorizontal: 16,
    paddingVertical: 16,
    zIndex: 0,
    elevation: 0,
  }
})
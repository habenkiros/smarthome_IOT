import { StyleSheet } from 'react-native'
import React from 'react'
import * as Yup from 'yup';
import { Formik } from 'formik';
import { Screen, Box, Text, TextField, Button, Picker, DateTimePicker } from 'components'
import AddedDevices from '../components/added-devices'
import { useDispatch, useSelector } from 'react-redux';
import { unwrapResult } from '@reduxjs/toolkit';
import { addBooking, updateBooking } from '../store';
import moment from 'moment';
import Toast from 'react-native-toast-message';

const AddBookingSchema = Yup.object().shape({
  guest_name: Yup.string().label("Guest name").required(),
  guest_contact: Yup.string().label("Guest contact").nullable().required(),
  arrival: Yup.date().default(() => new Date()).label("Arrival").required(),
  // date_range: Yup.number().label("Stay date range").nullable().required(),
  unit_id: Yup.number().label("Unit Number").nullable().required(),
  // departure: Yup.string().label("Departure").required()
  departure: Yup.date().default(null)
    .when("arrival",
      (arrival, Yup) => arrival && Yup.min(arrival, "Departure date cannot be before arrival date"))
  // .test("invalid-date-range", "Arrival date and departure are not within date range", (value, ctx) => {
  //   const arrival = moment(ctx.parent.arrival)
  //   const departure = moment(ctx.parent.departure)
  //   const duration = moment.duration(departure.diff(arrival));
  //   return ctx.parent.date_range === Math.round(duration.asDays())
  // })
});

const AddBookingScreen = ({ navigation, route }) => {
  const { api } = useSelector(state => state.dashboard)
  const units = useSelector(state => state.dashboard.units)
  const { booking } = route.params || {}
  const dispatch = useDispatch()

  return (
    <Screen preset='scroll' unsafe={true}>
      <Formik
        initialValues={
          booking?.id ?
            {
              ...booking,
              // date_range: Math.round(
              //   moment.duration(moment(booking.departure).diff(moment(booking.arrival))).asDays()
              // ),
              unit_id: booking.unit.id,
            } :
            {
              guest_name: '',
              guest_contact: '',
              arrival: new Date(),
              departure: new Date(),
              unit_id: '',
              // date_range: 0
            }}
        onSubmit={(values, { resetForm }) => {
          if (booking?.id) {
            dispatch(updateBooking(values))
              .then(unwrapResult)
              .then(() => {
                Toast.show({
                  type: 'success',
                  text1: 'Successfully updated the booking',
                })
              })
          } else {
            dispatch(addBooking(values))
              .then(unwrapResult)
              .then(() => {
                resetForm();
                Toast.show({
                  type: 'success',
                  text1: 'Successfully created a booking',
                })
              })
          }
        }}
        validationSchema={AddBookingSchema}
      >
        {({ handleChange, handleBlur, handleSubmit, values, errors, touched, setFieldValue, setTouched }) => (
          <Box style={styles.container}>
            <Text variant='h3'>{booking?.id ? "Edit" : "Add"} New Booking</Text>
            <Box mv={10}>
              <TextField
                label='Guest name'
                placeholder='Enter your guest name'
                onChangeText={handleChange('guest_name')}
                onBlur={handleBlur('guest_name')}
                value={values.guest_name}
                error={touched.guest_name && errors.guest_name}
              />
            </Box>
            <Box mv={10}>
              <TextField
                label='Guest contact'
                placeholder='Enter your guest contact'
                onChangeText={handleChange('guest_contact')}
                onBlur={handleBlur('guest_contact')}
                value={values.guest_contact}
                error={touched.guest_contact && errors.guest_contact}
              />
            </Box>
            {/* <Box mv={10}>
              <Picker
                label='Select stay date range'
                placeholder='Select stay date range'
                onChange={(v) => {
                  setFieldValue('date_range', v)
                  setFieldValue('departure', moment(values.arrival).add(v, 'days'))
                  // setTouched('departure', true)
                }}
                value={values.date_range}
                error={errors.date_range}
                options={[
                  { label: '1', value: 1 },
                  { label: '2', value: 2 },
                  { label: '3', value: 3 },
                  { label: '4', value: 4 },
                ]}
              />
            </Box> */}
            <Box mv={10}>
              <DateTimePicker
                label='Arrival'
                placeholder=''
                onChange={(v) => setFieldValue('arrival', v)}
                value={values.arrival}
                error={errors.arrival}
              />
            </Box>
            <Box mv={10}>
              <DateTimePicker
                label='Departure'
                placeholder=''
                onChange={(v) => setFieldValue('departure', v)}
                value={values.departure}
                error={touched.departure && errors.departure}

              />
            </Box>
            <Box mv={10}>
              <Picker
                label='Unit'
                placeholder='Select your unit'
                onChange={(v) => setFieldValue('unit_id', v)}
                value={values.unit_id}
                error={touched.unit_id && errors.unit_id}
                options={units.map(u => ({ label: u.name, value: u.id }))}
              />
            </Box>
            <Box style={styles.deviceContentTitle}>
              <Text variant='strong'>Devices added</Text>
            </Box>
            <Box>
              {
                units.find(u => u.id === values.unit_id)?.devices.map(d => <AddedDevices device={d} />)
              }
            </Box>
            <Button
              onPress={handleSubmit}
              loading={api.loading}
              text="Save and continue"
            />
          </Box>
        )}
      </Formik>

    </Screen>
  )
}

export default AddBookingScreen

const styles = StyleSheet.create({
  container: {
    padding: 16,
    flex: 1,
  },
  deviceContentTitle: {
    paddingVertical: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  row: {
    flexDirection: 'row'
  }
})
import { StyleSheet } from 'react-native'
import React, { useEffect } from 'react'
import { Screen, Box, Text } from 'components'
import AddedDevices from '../components/added-devices'

const UnitViewScreen = ({ route }) => {
  const { unit } = route.params
  return (
    <Screen preset='scroll' unsafe={true}>
      <Box style={styles.container}>
        <Text variant='h3'>Unit Information</Text>
        <Box style={styles.content}>
          <Box>
            <Text variant='footNote' style={styles.label}>Unit address</Text>
            <Text variant='strong' style={styles.text}>{unit.address}</Text>
          </Box>
          <Box>
            <Text variant='footNote' style={styles.label}>Unit number</Text>
            <Text variant='strong' style={styles.text}>{unit.number}</Text>
          </Box>
          <Box>
            <Text variant='footNote' style={styles.label}>Unit name</Text>
            <Text variant='strong' style={styles.text}>{unit.name}</Text>
          </Box>
        </Box>
        <Text variant='strong'>Devices</Text>
        <Box mt={10}>
          {
            unit.devices?.map(d => <AddedDevices key={d.id} device={d} />)
          }
        </Box>
      </Box>
    </Screen>
  )
}

export default UnitViewScreen

const styles = StyleSheet.create({
  container: {
    padding: 16,
    flex: 1,
  },
  deviceContentTitle: {
    paddingVertical: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  row: {
    flexDirection: 'row'
  },
  content: {
    backgroundColor: '#ffff',
    borderRadius: 16,
    padding: 16,
    marginTop: 16,
    marginBottom: 24
  },
  label: {
    marginBottom: 4
  },
  text: {
    marginBottom: 16
  }
})
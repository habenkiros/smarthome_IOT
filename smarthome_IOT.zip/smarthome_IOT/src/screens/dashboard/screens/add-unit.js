import { Pressable, StyleSheet, Image } from 'react-native'
import React, { useEffect, useRef, useState } from 'react'
import * as Yup from 'yup';
import { Formik } from 'formik';
import { Screen, Box, Text, TextField, Button } from 'components'
import AntDesign from 'react-native-vector-icons/AntDesign'
import FeatherIcon from 'react-native-vector-icons/Feather'
import AddedDevices from '../components/added-devices'
import { useDispatch, useSelector } from 'react-redux';
import { addUnitRequest, updateUnitRequest, getDevices } from '../store';
import DevicesBottomSheet from '../components/devices-bottomsheet';
import { unwrapResult } from '@reduxjs/toolkit';
import Toast from 'react-native-toast-message';
import { launchImageLibrary } from 'react-native-image-picker';
import FontAwesome from 'react-native-vector-icons/FontAwesome';

const AddUnitSchema = Yup.object().shape({
  name: Yup.string().label("Name").required(),
  number: Yup.number().typeError('Unit number must be a number').label("Unit number").nullable().required(),
  address: Yup.string().label("Address").required(),
  city: Yup.string().label("City").required(),
  country: Yup.string().label("Country").required(),
  zip_code: Yup.string().label("Zip code").required(),
});

const AddUnitScreen = () => {
  const { api } = useSelector(state => state.dashboard)
  const selectedUnit = useSelector(state => state.dashboard.selectedUnit)
  const devices = useSelector(state => state.dashboard.devices)
  const bottomSheetRef = useRef(null);
  const dispatch = useDispatch()

  useEffect(() => {
    dispatch(getDevices())
  }, [])

  const filterDevices = (addedDevices) => devices.map(d => {
    var obj = d;
    if (addedDevices?.find(ad => ad.id === d.id)) {
      obj = { ...d, added: true }
    }
    return obj
  })

  const onSelectImage = async (setFieldValue) => {
    const result = await launchImageLibrary({
      includeBase64: true,
      mediaType: 'photo',
      quality: 0.3,
    });

    setFieldValue('image_encoded', `data:image/jpeg;base64,${result.assets[0].base64}`)
  }

  return (
    <Formik
      initialValues={selectedUnit?.id ? {
        ...selectedUnit,
        devices_list: selectedUnit.devices,
        number: selectedUnit.number?.toString(),
        image_encoded: selectedUnit.image
      } : {
        name: '',
        number: '',
        address: '',
        city: '',
        country: '',
        zip_code: '',
        devices_list: [],
        image_encoded: ''
      }}
      onSubmit={(values, { resetForm }) => {
        if (selectedUnit?.id) {
          dispatch(updateUnitRequest(values))
            .then(unwrapResult)
            .then(() => {
              Toast.show({
                type: 'success',
                text1: 'Successfully updated the unit',
              })
            })
        } else {
          dispatch(addUnitRequest(values))
            .then(unwrapResult)
            .then(() => {
              resetForm()
              Toast.show({
                type: 'success',
                text1: 'Successfully added the unit',
              })
            })
        }
      }}
      validationSchema={AddUnitSchema}
    >
      {({ handleChange, handleBlur, handleSubmit, setFieldValue, values, errors, touched }) => (
        <>
          <Screen preset='scroll' unsafe={true}>
            <Box style={styles.container}>
              <Text variant='h3'>{selectedUnit?.id ? "Edit" : "Add"} New Unit</Text>
              <Box mv={10}>
                <TextField
                  label='Unit name'
                  placeholder='Enter your unit name'
                  onChangeText={handleChange('name')}
                  onBlur={handleBlur('name')}
                  value={values.name}
                  error={touched.name && errors.name}
                />
              </Box>
              <Box mv={10}>
                <TextField
                  label='Unit number'
                  placeholder='Enter your unit number'
                  onChangeText={handleChange('number')}
                  onBlur={handleBlur('number')}
                  value={values.number}
                  error={touched.number && errors.number}
                />
              </Box>
              <Box mv={10}>
                <TextField
                  label='Address'
                  placeholder='Enter your address'
                  onChangeText={handleChange('address')}
                  onBlur={handleBlur('address')}
                  value={values.address}
                  error={touched.address && errors.address}
                />
              </Box>
              <Box mv={10}>
                <TextField
                  label='City'
                  placeholder='Select your city'
                  onChangeText={handleChange('city')}
                  onBlur={handleBlur('city')}
                  value={values.city}
                  error={touched.city && errors.city}
                />
              </Box>
              <Box mv={10}>
                <TextField
                  label='Zip code'
                  placeholder='Select your zip code'
                  onChangeText={handleChange('zip_code')}
                  onBlur={handleBlur('zip_code')}
                  value={values.zip_code}
                  error={touched.zip_code && errors.zip_code}
                />
              </Box>
              <Box mv={10}>
                <TextField
                  label='State'
                  placeholder='Select your state'
                  onChangeText={handleChange('state')}
                  onBlur={handleBlur('state')}
                  value={values.state}
                  error={touched.state && errors.state}
                />
              </Box>
              <Box mv={10}>
                <TextField
                  label='Country'
                  placeholder='Select your country'
                  onChangeText={handleChange('country')}
                  onBlur={handleBlur('country')}
                  value={values.country}
                  error={touched.country && errors.country}
                />
              </Box>

              <Box mv={10}>
                <Text variant='label' color='text' style={{ marginBottom: 6 }}>Image</Text>
                <Pressable onPress={() => onSelectImage(setFieldValue)}>
                  <Box style={styles.uploadBtn}>
                    {values.image_encoded ?
                      <Box style={styles.imageContainer}>
                        <Image source={{ uri: values.image_encoded }} style={styles.uploadBtn} />
                        <Box style={styles.editBtn}>
                          <FontAwesome name='edit' size={20} />
                        </Box>
                      </Box>
                      :
                      <AntDesign name='plus' size={36} />}
                  </Box>
                </Pressable>
              </Box>

              <Box style={styles.deviceContentTitle}>
                <Text variant='strong'>Devices added</Text>
                <Pressable onPress={() => bottomSheetRef.current.snapToIndex(0)}>
                  <Box style={styles.row}>
                    <AntDesign name='plus' size={20} />
                    <Text> Add new device</Text>
                  </Box>
                </Pressable>
              </Box>
              <Box>
                {
                  values.devices_list?.map(d => <AddedDevices key={d.id} device={d} />)
                }
              </Box>
              <Button
                text="Edit devices"
                onPress={() => bottomSheetRef.current.snapToIndex(0)}
                variant='outline'
                rightIcon={<FeatherIcon name='edit' size={20} />}
                style={{ marginBottom: 10 }}
              />
              <Button
                onPress={handleSubmit}
                loading={api.loading}
                text="Save and continue"
              />
            </Box>
          </Screen>
          <DevicesBottomSheet
            bottomSheetRef={bottomSheetRef}
            devices={filterDevices(values.devices_list)}
            addDevice={(device) => setFieldValue('devices_list', [...values.devices_list, device])}
            removeDevice={(device) => setFieldValue('devices_list', values.devices_list.filter(d => d.id !== device.id).map(d => d))}
          />
        </>
      )}
    </Formik>
  )
}

export default AddUnitScreen

const styles = StyleSheet.create({
  container: {
    padding: 16,
    flex: 1,
  },
  deviceContentTitle: {
    paddingVertical: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  row: {
    flexDirection: 'row'
  },
  uploadBtn: {
    backgroundColor: '#e2e2e2',
    alignSelf: 'flex-start',
    borderRadius: 10,
    height: 80,
    width: 80,
    justifyContent: 'center',
    alignItems: 'center'
  },
  imageContainer: {
    position: 'relative'
  },
  editBtn: {
    position: 'absolute',
    right: -2,
    bottom: -2,
    padding: 6,
    backgroundColor: '#e2e2e2',
    borderRadius: 20
  }
})
import React, { useMemo } from 'react';
import { Pressable, StyleSheet, Image } from 'react-native';
import RNBottomSheet from '@gorhom/bottom-sheet';
import { Box, Text } from 'components';
import AntDesign from 'react-native-vector-icons/AntDesign'
import { color } from 'utils';

const DevicesBottomSheet = ({ bottomSheetRef, devices, addDevice, removeDevice }) => {
  const snapPoints = useMemo(() => ['80%'], []);

  return (
    <RNBottomSheet
      ref={bottomSheetRef}
      index={-1}
      snapPoints={snapPoints}
      enablePanDownToClose={true}
      handleComponent={null}
      backgroundStyle={styles.container}
      style={{
        shadowColor: "#000",
        shadowOffset: {
          width: 0,
          height: 2,
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62,

        elevation: 4,
      }}
    >
      <Box pt={20}>
        <Box pb={20} style={{ borderBottomWidth: 1, borderBottomColor: '#D7D5D5' }}>
          <Text variant='strong' textAlign='center'>Edit Devices</Text>
          <Pressable style={styles.closeBtn} onPress={() => bottomSheetRef.current.close()}>
            <AntDesign name='close' size={20} />
          </Pressable>
        </Box>
        {
          devices.map((device, index) => <Box style={styles.contentContainer} key={index} paddingTop={index === 0 ? 20 : 0}>
            <Box style={styles.item}>
              <Image
                source={{ uri: 'https://www.wattagnet.com/ext/resources/lightbulb-graphic-on-yellow.jpg' }}
                style={styles.icon}
              />
              <Text variant='strong'>{device.name}</Text>
            </Box>
            {
              device.added ? <Pressable style={styles.button} onPress={() => removeDevice(device)}>
                <AntDesign name='delete' size={20} color={color.error} />
                <Text variant='label' color='error'> Remove</Text>
              </Pressable> :
                <Pressable style={styles.button} onPress={() => addDevice(device)}>
                  <AntDesign name='plus' size={20} />
                  <Text variant='label'> Add</Text>
                </Pressable>
            }

          </Box>)
        }
      </Box>
    </RNBottomSheet>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 50,
  },
  contentContainer: {
    paddingHorizontal: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: 15,
    marginTop: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F5F9',
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 16,
  },
  button: {
    padding: 8,
    borderBottomWidth: 1,
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: '#F3F5F9',
    alignSelf: 'center',
    borderRadius: 8
  },
  closeBtn: {
    position: 'absolute',
    right: 30,
    backgroundColor: '#F3F5F9',
    padding: 5,
    borderRadius: 20,
    bottom: 15
  }
});

export default DevicesBottomSheet;
import { Box, Text } from 'components'
import React from 'react'
import { StyleSheet, Pressable, } from 'react-native'
import { color } from 'utils'

const Tabs = ({ state, descriptors, navigation, onTabChange }) => {
  return (
    <Box style={styles.container}>
      {state.routes.map((route, index) => {
        const { options } = descriptors[route.key];
        const label =
          options.tabBarLabel !== undefined
            ? options.tabBarLabel
            : options.title !== undefined
              ? options.title
              : route.name;

        const isFocused = state.index === index;

        const onPress = () => {
          onTabChange(route.name)
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
            canPreventDefault: true,
          });

          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate({ name: route.name, merge: true });
          }
        };

        const onLongPress = () => {
          navigation.emit({
            type: 'tabLongPress',
            target: route.key,
          });
        };


        return (
          <Pressable
            accessibilityRole="button"
            accessibilityState={isFocused ? { selected: true } : {}}
            accessibilityLabel={options.tabBarAccessibilityLabel}
            testID={options.tabBarTestID}
            onPress={onPress}
            onLongPress={onLongPress}
            style={[styles.button, isFocused && { borderColor: color.primary }]}
          >
            {options.tabBarIcon(isFocused)}
            <Text style={{ color: isFocused ? color.primary : '#898989' }} variant={isFocused ? "strong" : 'text'}>
              {label}
            </Text>
          </Pressable>
        );
      })}
    </Box>
  )
}

export default Tabs

const styles = StyleSheet.create({
  container: {
    padding: 16,
    paddingBottom: 0,
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  button: {
    backgroundColor: 'white',
    height: 56,
    borderRadius: 16,
    width: '48%',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: '#D4C8BA'
  }
})
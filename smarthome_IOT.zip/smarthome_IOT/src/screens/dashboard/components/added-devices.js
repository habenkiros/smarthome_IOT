import { StyleSheet, Image } from 'react-native'
import React, { useState } from 'react'
import { Box, Switch, Text } from 'components'

const AddedDevices = ({ device = {} }) => {
  const [on, onSwitch] = useState(false)
  return (
    <Box style={styles.content}>
      <Box style={styles.row}>
        <Image
          source={{ uri: 'https://www.wattagnet.com/ext/resources/lightbulb-graphic-on-yellow.jpg' }}
          style={styles.icon}
        />
        <Box>
          <Text variant='strong'>{device.name}</Text>
          <Text >{device.status}</Text>
        </Box>
      </Box>
      <Switch value={on} onSwitch={onSwitch} />
    </Box>
  )
}

export default AddedDevices

const styles = StyleSheet.create({
  content: {
    padding: 16,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#F2F6FD'
  },
  icon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10
  },
  row: {
    flexDirection: 'row'
  }
})
import React, { useState } from 'react'
import { StyleSheet, View, Dimensions } from 'react-native'
import { Box, Text } from 'components'
import moment from 'moment'
import { TouchableOpacity } from 'react-native-gesture-handler'
import FontAwesome from 'react-native-vector-icons/FontAwesome'

const { width } = Dimensions.get('screen')

const CalendarDailyView = ({ markedDates }) => {
  const [startDate, setStartDate] = useState(moment())

  const selectedDateStyle = (markedDate) => ({
    backgroundColor: markedDate.color,
    borderTopLeftRadius: markedDate.startingDay ? 8 : 0,
    borderBottomLeftRadius: markedDate.startingDay ? 8 : 0,
    borderTopRightRadius: markedDate.endingDay ? 8 : 0,
    borderBottomRightRadius: markedDate.endingDay ? 8 : 0,
    marginHorizontal: 0,
    marginLeft: markedDate.startingDay ? 4 : 0,
    marginRight: markedDate.endingDay ? 4 : 0,

  })

  return (
    <Box style={styles.container}>
      <Box style={styles.selectedDateContent}>
        <TouchableOpacity onPress={() => { setStartDate(moment(startDate).add(-1, 'days')) }}>
          <FontAwesome name='angle-left' size={28} color='#888a88' />
        </TouchableOpacity>
        <Text variant='strong'>{startDate.format('MMMM')} {startDate.format('yyy')}</Text>
        <TouchableOpacity onPress={() => { setStartDate(moment(startDate).add(1, 'days')) }}>
          <FontAwesome name='angle-right' size={28} color='#888a88' />
        </TouchableOpacity>
      </Box>
      <Box style={styles.calendarContent}>
        <Box style={styles.weekDayContent}>
          <Text style={styles.day} >{startDate.format('ddd')}</Text>
          <View style={[styles.markedDate, markedDates[startDate.format("yyyy-MM-DD")] && selectedDateStyle(markedDates[startDate.format("yyyy-MM-DD")])]}>
            <Text
              style={styles.day}
              color={
                startDate.format('DD') === moment(new Date()).format('DD') ? 'black' : 'darkGray'
              }>{startDate.format('DD')}</Text>
          </View>
        </Box>
      </Box>
    </Box>
  )
}

export default CalendarDailyView

const styles = StyleSheet.create({
  container: {
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1
  },
  weekDayContent: {
    justifyContent: 'center',
    // width: width,
    width: 40
  },
  day: {
    fontSize: 14,
    color: '#888a88',
    fontWeight: '600',
    textAlign: 'center'
  },
  selectedDateContent: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    width: '100%'
  },
  calendarContent: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  image: {
    width: 20,
    height: 20,
    marginRight: 10
  },
  arrow: {
    width: 20,
    height: 20
  },
  markedDate: {
    marginHorizontal: 5,
    alignItems: 'center',
    paddingVertical: 5
  }
})



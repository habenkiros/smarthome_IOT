import { Pressable, StyleSheet } from 'react-native'
import React from 'react'
import { Box } from 'components'
import IoniconsIcon from 'react-native-vector-icons/Ionicons'
import AntDesign from 'react-native-vector-icons/AntDesign'

const RightButton = ({ navigation, onAdd }) => {
  return (
    <Box style={styles.content}>
      <Pressable style={styles.button} onPress={onAdd}>
        <AntDesign name='plus' size={28} />
      </Pressable>
      <Pressable style={styles.button}>
        <IoniconsIcon name='notifications-outline' size={28} />
      </Pressable>
    </Box>
  )
}

export default RightButton

const styles = StyleSheet.create({
  content: {
    flexDirection: 'row',
    marginLeft: 22,
    marginRight: 16,
  },
  button: {
    marginHorizontal: 4
  }
})
import React, { useMemo } from 'react';
import { Pressable, StyleSheet } from 'react-native';
import RNBottomSheet from '@gorhom/bottom-sheet';
import { Box, Text } from 'components';
import FeatherIcon from 'react-native-vector-icons/Feather'
import AntDesign from 'react-native-vector-icons/AntDesign'
import { color } from 'utils';

const BottomSheet = ({ bottomSheetRef, navigation, deleteHandler }) => {
  const snapPoints = useMemo(() => ['30%'], []);

  return (
    <RNBottomSheet
      ref={bottomSheetRef}
      index={-1}
      snapPoints={snapPoints}
      // onChange={handleSheetChanges}
      enablePanDownToClose={true}
      handleComponent={null}
      backgroundStyle={styles.container}

    >
      <Box style={styles.contentContainer}>
        <Pressable style={styles.item} onPress={() => [navigation.navigate("AddUnitScreen"), bottomSheetRef.current.close()]}>
          <FeatherIcon name='edit' size={24} style={styles.icon} />
          <Text variant='label'>Edit unit information</Text>
        </Pressable>
        <Pressable style={styles.item}>
          <FeatherIcon name='settings' size={24} style={styles.icon} />
          <Text variant='label'>Device settings</Text>
        </Pressable>
        <Pressable style={styles.item} onPress={deleteHandler}>
          <AntDesign name='delete' size={24} style={styles.icon} color={color.error} />
          <Text variant='label' color='error'>Delete unit</Text>
        </Pressable>
      </Box>
    </RNBottomSheet>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 50
  },
  contentContainer: {
    paddingHorizontal: 20,
    paddingTop: 20
  },
  item: {
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F5F9',
    flexDirection: 'row',
    alignContent: 'center',
  },
  icon: {
    marginRight: 16,
    marginTop: -1
  }
});

export default BottomSheet;
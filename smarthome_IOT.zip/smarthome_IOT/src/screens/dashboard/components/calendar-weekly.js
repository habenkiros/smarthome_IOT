import React, { useState } from 'react'
import { StyleSheet, View, Dimensions } from 'react-native'
import { Box, Text } from 'components'
import moment from 'moment'
import { TouchableOpacity } from 'react-native-gesture-handler'
import FontAwesome from 'react-native-vector-icons/FontAwesome'

const { width } = Dimensions.get('screen')

const CalendarWeeklyView = ({ markedDates }) => {
  const [startDate, setStartDate] = useState(moment())
  var weekStart = startDate.clone().startOf('week');
  var days = [];
  for (var i = 0; i <= 6; i++) {
    days.push(moment(weekStart).add(i, 'days'));
  };

  const selectedDateStyle = (markedDate) => ({
    backgroundColor: markedDate.color,
    borderTopLeftRadius: markedDate.startingDay ? 8 : 0,
    borderBottomLeftRadius: markedDate.startingDay ? 8 : 0,
    borderTopRightRadius: markedDate.endingDay ? 8 : 0,
    borderBottomRightRadius: markedDate.endingDay ? 8 : 0,
    marginHorizontal: 0,
    marginLeft: markedDate.startingDay ? 4 : 0,
    marginRight: markedDate.endingDay ? 4 : 0,

  })

  return (
    <Box style={styles.container}>
      <Box style={styles.selectedDateContent}>
        <TouchableOpacity onPress={() => { setStartDate(moment(weekStart).add(-7, 'days')) }}>
          <FontAwesome name='angle-left' size={28} color='#888a88' />
        </TouchableOpacity>
        <Text variant='strong'>{startDate.format('MMMM')} {startDate.format('yyy')}</Text>
        <TouchableOpacity onPress={() => { setStartDate(moment(weekStart).add(7, 'days')) }}>
          <FontAwesome name='angle-right' size={28} color='#888a88' />
        </TouchableOpacity>
      </Box>
      <Box style={styles.calendarContent}>
        {
          days.map((d, i) => {
            const date = markedDates[d.format("yyyy-MM-DD")]
            return (
              <Box style={styles.weekDayContent}>
                <Text style={styles.day} >{d.format('ddd')}</Text>
                <View style={[styles.markedDate, date && selectedDateStyle(date)]}>
                  <Text
                    color={
                      d.format('DD') === moment(new Date()).format('DD') ? 'black' : 'darkGray'
                    }>{d.format('DD')}</Text>
                </View>
              </Box>
            )
          })
        }
      </Box>
    </Box>
  )
}

export default CalendarWeeklyView

const styles = StyleSheet.create({
  container: {
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1
  },
  weekDayContent: {
    justifyContent: 'center',
    width: (width / 8) + 4,
  },
  day: {
    fontSize: 12,
    color: '#888a88',
    fontWeight: '400',
    textAlign: 'center'
  },
  selectedDateContent: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    width: '100%'
  },
  calendarContent: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  image: {
    width: 20,
    height: 20,
    marginRight: 10
  },
  arrow: {
    width: 20,
    height: 20
  },
  markedDate: {
    marginHorizontal: 5,
    alignItems: 'center',
    paddingVertical: 5
  }
})



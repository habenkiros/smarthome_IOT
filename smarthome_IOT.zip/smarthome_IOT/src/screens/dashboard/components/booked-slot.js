import { Pressable, StyleSheet } from 'react-native'
import React from 'react'
import { Box, Text } from 'components'
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5'
import moment from 'moment'

const BookedSlot = ({ booking, onDelete, onEdit }) => {
  return (
    <Box style={styles.content}>
      <Box flexDirection="row" justifyContent="space-between" alignItems="center" width='100%'>
        <Box>
          <Text variant='strong'>Booked by {booking.guest_name}</Text>
          <Text>{moment(booking.arrival).format("Do MMM")} - {moment(booking.departure).format("Do MMM")}</Text>
        </Box>
        <Box flexDirection="row">
          <Pressable onPress={onEdit}>
            <FontAwesome5 name='edit' size={22} color='#2225FF' style={{ marginRight: 16 }} />
          </Pressable>
          <Pressable onPress={onDelete}>
            <FontAwesome5 name='trash-alt' size={22} color='#FF002E' style={{ marginRight: 16 }} />
          </Pressable>
        </Box>
      </Box>
    </Box>
  )
}

export default BookedSlot

const styles = StyleSheet.create({
  content: {
    backgroundColor: '#ffff',
    padding: 16,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 16,
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: '#F2F6FD'
  },

})
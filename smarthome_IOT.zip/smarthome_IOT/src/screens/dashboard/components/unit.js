import { StyleSheet, Image, Pressable } from 'react-native'
import React from 'react'
import { Box, Text } from 'components'
import IoniconsIcon from 'react-native-vector-icons/Ionicons'

const Unit = ({ image, title, subText, openSheet, onClick }) => {
  return (
    <Pressable onPress={onClick}>
      <Box style={styles.content}>
        <Image
          source={{ uri: image }}
          style={styles.image}
        />
        <Box ph={12} pv={12} style={styles.textContent}>
          <Box mr={5} style={{ flex: 1 }}>
            <Text variant='strong'>{title}</Text>
            <Text>{subText}</Text>
          </Box>
          <Pressable onPress={openSheet}>
            <IoniconsIcon name='ellipsis-horizontal' size={28} />
          </Pressable>
        </Box>
      </Box>
    </Pressable>
  )
}

export default Unit

const styles = StyleSheet.create({
  content: {
    backgroundColor: '#ffff',
    borderRadius: 16,
    marginBottom: 16
  },
  image: {
    height: 152,
    width: '100%',
    borderTopRightRadius: 16,
    borderTopLeftRadius: 16
  },
  textContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    // flexWrap: 'wrap',
  }
})
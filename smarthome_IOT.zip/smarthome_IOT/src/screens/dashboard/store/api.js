import httpClient from 'utils/httpClient'

function apiGetUnitsRequest() {
  return httpClient.get(`/api/unit/`)
}

function apiAddUnitRequest(payload) {
  return httpClient.post(`/api/unit/`, payload)
}

function apiUpdateUnitRequest(payload) {
  return httpClient.patch(`/api/unit/${payload.id}/`, payload)
}

function apiDeleteUnitRequest(id) {
  return httpClient.delete(`/api/unit/${id}/`)
}

function apiGetBookingsRequest() {
  return httpClient.get(`/api/booking/`)
}

function apiAddBookingRequest(payload) {
  return httpClient.post(`/api/booking/`, payload)
}

function apiGetDevicesRequest() {
  return httpClient.get(`/api/devices/`)
}

function apiDeleteBookingRequest(id) {
  return httpClient.delete(`/api/booking/${id}/`)
}

function apiUpdateBookingRequest(payload) {
  return httpClient.patch(`/api/booking/${payload.id}/`, payload)
}

export const api = {
  apiGetUnitsRequest,
  apiAddUnitRequest,
  apiUpdateUnitRequest,
  apiDeleteUnitRequest,
  apiGetBookingsRequest,
  apiAddBookingRequest,
  apiGetDevicesRequest,
  apiDeleteBookingRequest,
  apiUpdateBookingRequest,
}

import { createSlice, createAsyncThunk } from "@reduxjs/toolkit"
import { getServerError } from "utils/utils"
import { api } from "./api"

export const getUnitsRequest = createAsyncThunk(
  "dashboard/getUnits",
  async () => {
    try {
      const response = await api.apiGetUnitsRequest()
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const addUnitRequest = createAsyncThunk(
  "dashboard/addUnit",
  async (payload) => {
    try {
      const response = await api.apiAddUnitRequest(payload)
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const updateUnitRequest = createAsyncThunk(
  "dashboard/updateUnit",
  async (payload) => {
    try {
      const response = await api.apiUpdateUnitRequest(payload)
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const deleteUnitRequest = createAsyncThunk(
  "dashboard/deleteUnit",
  async (payload) => {
    try {
      await api.apiDeleteUnitRequest(payload)
      return payload
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const getBookings = createAsyncThunk(
  "dashboard/getBookings",
  async () => {
    try {
      const response = await api.apiGetBookingsRequest()
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const addBooking = createAsyncThunk(
  "dashboard/addBookings",
  async (payload) => {
    try {
      const response = await api.apiAddBookingRequest(payload)
      debugger
      return response.data
    } catch (err) {
      debugger
      console.log(error)
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const getDevices = createAsyncThunk(
  "dashboard/getDevices",
  async (payload) => {
    try {
      const response = await api.apiGetDevicesRequest(payload)
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const deleteBooking = createAsyncThunk(
  "dashboard/deleteBooking",
  async (payload) => {
    try {
      await api.apiDeleteBookingRequest(payload)
      return payload
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)

export const updateBooking = createAsyncThunk(
  "dashboard/updateBooking",
  async (payload) => {
    try {
      const response = await api.apiUpdateBookingRequest(payload)
      return response.data
    } catch (err) {
      let errorMsg = getServerError(err.response?.data) || JSON.stringify(err.response || err);
      throw new Error(errorMsg)
    }
  }
)


export const initialDashboardState = {
  units: [],
  api: { loading: false, error: null },
  deleteBooking: { loading: false, error: null },
  selectedUnit: {},
  bookings: [],
  devices: []
}
export const dashboardSlice = createSlice({
  name: "dashboard",
  initialState: initialDashboardState,
  reducers: {
    selectUnit: (state, action) => {
      state.selectedUnit = action.payload
    },
  },
  extraReducers: {
    [getUnitsRequest.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [getUnitsRequest.fulfilled]: (state, action) => {
      state.api.loading = false
      state.units = action.payload
    },
    [getUnitsRequest.rejected]: (state, action) => {
      state.api.loading = true
      state.api.error = action.error
    },
    [addUnitRequest.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [addUnitRequest.fulfilled]: (state, action) => {
      state.api.loading = false
      state.units = [...state.units, action.payload]
    },
    [addUnitRequest.rejected]: (state, action) => {
      state.api.loading = false
      state.api.error = action.error
    },
    [updateUnitRequest.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [updateUnitRequest.fulfilled]: (state, action) => {
      state.api.loading = false
      state.units = state.units.map(u => u.id === action.payload.id ? action.payload : u)
    },
    [updateUnitRequest.rejected]: (state, action) => {
      state.api.loading = false
      state.api.error = action.error
    },
    [deleteUnitRequest.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [deleteUnitRequest.fulfilled]: (state, action) => {
      state.api.loading = false
      state.units = state.units.filter(u => u.id !== action.payload)
    },
    [deleteUnitRequest.rejected]: (state, action) => {
      state.api.loading = false
      state.api.error = action.error
    },
    [getBookings.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [getBookings.fulfilled]: (state, action) => {
      state.api.loading = false
      state.bookings = action.payload
    },
    [getBookings.rejected]: (state, action) => {
      state.api.loading = true
      state.api.error = action.error
    },

    [getDevices.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [getDevices.fulfilled]: (state, action) => {
      state.api.loading = false
      state.devices = action.payload
    },
    [getDevices.rejected]: (state, action) => {
      state.api.loading = true
      state.api.error = action.error
    },

    [addBooking.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [addBooking.fulfilled]: (state, action) => {
      state.api.loading = false
      state.bookings = [...state.bookings, action.payload]
    },
    [addBooking.rejected]: (state, action) => {
      state.api.loading = false
      state.api.error = action.error
    },
    [deleteBooking.pending]: state => {
      state.deleteBooking.loading = true
      state.deleteBooking.error = null
    },
    [deleteBooking.fulfilled]: (state, action) => {
      state.deleteBooking.loading = false
      state.bookings = state.bookings.filter(b => b.id !== action.payload)
    },
    [deleteBooking.rejected]: (state, action) => {
      state.deleteBooking.loading = false
      state.deleteBooking.error = action.error
    },

    [updateBooking.pending]: state => {
      state.api.loading = true
      state.api.error = null
    },
    [updateBooking.fulfilled]: (state, action) => {
      state.api.loading = false
      state.bookings = state.bookings.map(b => b.id === action.payload.id ? action.payload : b)
    },
    [updateBooking.rejected]: (state, action) => {
      state.api.loading = false
      state.api.error = action.error
    },
  }
})

export const { selectUnit } = dashboardSlice.actions


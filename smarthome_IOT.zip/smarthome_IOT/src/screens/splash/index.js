import { ImageBackground, StyleSheet, Image } from 'react-native'
import React, { useEffect } from 'react'
import { Box, Text, Button } from 'components'
import { SafeAreaView } from 'react-native-safe-area-context'
import LinearGradient from 'react-native-linear-gradient';
import { useSelector } from 'react-redux';

const SplashScreen = ({ navigation }) => {

  const user = useSelector((state) => state.auth.user);
  const api = useSelector((state) => state.auth.api);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (!api.loading) {
        if (!user.email) {
          navigation.navigate('SignInScreen')
        } else {
          navigation.navigate('App')
        }
      }
    }, 2000);
    return () => clearTimeout(timer);
  }, [user, api]);

  return (
    <ImageBackground source={require("assets/images/splash-background.png")} style={styles.imageBg}>
      <LinearGradient
        colors={['rgba(255, 255, 255, 0)', 'rgba(0, 0, 0, 0.6)']}
        style={styles.bgGradient}
      >
        <SafeAreaView style={{ flex: 1 }}>
          <Box mt={20} style={styles.logoContent} >
            <Image source={require("assets/images/logo.png")} style={styles.logo} />
          </Box>
          <Box style={styles.content}>
            <Box style={styles.content}>
              <Text variant='h1' color='white'>Control your smart devices</Text>
              <Text variant='text' color='white'>Save time and money when you communicate and control your smart devices </Text>
            </Box>
          </Box>
        </SafeAreaView>
      </LinearGradient>
    </ImageBackground>
  )
}

export default SplashScreen

const styles = StyleSheet.create({
  imageBg: {
    height: '100%',
    width: '100%',
    flex: 1,
  },
  logo: {
    width: 164,
    height: 164
  },
  logoContent: {
    justifyContent: 'center',
    alignItems: 'center'
  },
  content: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: 16,
    paddingBottom: 20
  },
  bgGradient: {
    flex: 1,
  },
  button: {
    marginTop: 30
  }
})
import { StyleSheet } from 'react-native'
import React from 'react'
import { Screen, Box, Text, TextField, Button } from 'components'
import { useDispatch, useSelector } from 'react-redux'
import { Formik } from 'formik';
import * as Yup from 'yup';
import { updateUserProfile } from 'screens/auth/store';
import { unwrapResult } from '@reduxjs/toolkit';
import Toast from 'react-native-toast-message';

const ProfileSchema = Yup.object().shape({
  email: Yup.string().email().label("Email").required(),
  name: Yup.string().label("Name").required(),
  address: Yup.string().label("Address").required(),
});

const EditProfile = () => {
  const { user, api } = useSelector(state => state.auth)
  const dispatch = useDispatch();
  return (
    <Screen preset='scroll' unsafe={true}>
      <Formik
        initialValues={{ ...user }}
        onSubmit={values => dispatch(updateUserProfile(values))
          .then(unwrapResult)
          .then(() => Toast.show({
            type: 'success',
            text1: 'Successfully updated the user information',
          }))

        }
        validationSchema={ProfileSchema}
      >
        {({ handleChange, handleBlur, handleSubmit, values, errors, touched }) => (

          <Box style={styles.container}>
            <Text variant='h3'>Edit account information</Text>
            <Box mv={10}>
              <TextField
                label='Full name'
                placeholder='Enter your full name'
                onChangeText={handleChange('name')}
                onBlur={handleBlur('name')}
                value={values.name}
                error={touched.name && errors.name}
              />
            </Box>
            <Box mv={10}>
              <TextField
                label='Email address'
                placeholder='Enter your email address'
                onChangeText={handleChange('email')}
                onBlur={handleBlur('email')}
                value={values.email}
                error={touched.email && errors.email}
              />
            </Box>
            <Box mv={10}>
              <TextField
                label='Home address'
                placeholder='Enter your home address'
                onChangeText={handleChange('address')}
                onBlur={handleBlur('address')}
                value={values.address}
                error={touched.address && errors.address}
              />
            </Box>
            <Box mv={10}>
              <TextField
                label='City'
                placeholder='Select your city'
                onChangeText={handleChange('city')}
                onBlur={handleBlur('city')}
                value={values.city}
                error={touched.city && errors.city}
              />
            </Box>
            <Box mv={10}>
              <TextField
                label='Zip code'
                placeholder='Select your zip code'
                onChangeText={handleChange('zip_code')}
                onBlur={handleBlur('zip_code')}
                value={values.zip_code}
                error={touched.zip_code && errors.zip_code}
              />
            </Box>
            <Box mv={10}>
              <TextField
                label='State'
                placeholder='Select your state'
                onChangeText={handleChange('state')}
                onBlur={handleBlur('state')}
                value={values.state}
                error={touched.state && errors.state}
              />
            </Box>
            <Box mv={10}>
              <TextField
                label='Country'
                placeholder='Select your country'
                onChangeText={handleChange('country')}
                onBlur={handleBlur('country')}
                value={values.country}
                error={touched.country && errors.country}
              />
            </Box>
            <Button
              text="Save and continue"
              style={styles.button}
              onPress={handleSubmit}
              loading={api.loading}
            />
          </Box>
        )}
      </Formik>

    </Screen>
  )
}

export default EditProfile

const styles = StyleSheet.create({
  container: {
    padding: 16,
    flex: 1,
  },
  button: {
    marginTop: 20
  }

})
import { StyleSheet, Image, Pressable } from 'react-native'
import React from 'react'
import { launchImageLibrary } from 'react-native-image-picker';
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import { Box, Text, Button, Screen } from 'components'
import { useDispatch, useSelector } from 'react-redux'
import { updateUserProfile } from 'screens/auth/store';

const ProfileScreen = ({ navigation }) => {
  const { user } = useSelector(state => state.auth)
  const dispatch = useDispatch()

  const onSelectImage = async () => {
    const result = await launchImageLibrary({
      includeBase64: true,
      mediaType: 'photo',
      quality: 0.3,
    });

    dispatch(updateUserProfile({
      photo: result.assets[0].base64
    }))
  }

  return (
    <Screen preset='scroll' unsafe={true} style={styles.container}>
      <Box style={styles.profileImageContent}>
        <Box style={styles.imageContainer}>
          <Image
            style={styles.profileImage}
            source={{ uri: 'https://img.freepik.com/free-vector/businessman-character-avatar-isolated_24877-60111.jpg' }}
          />
          <Pressable style={styles.editBtn} onPress={onSelectImage}>
            <FontAwesome name='edit' size={20} />
          </Pressable>
        </Box>
        <Box>
          <Text variant='strong'>{user.name}</Text>
          <Text>{user.email}</Text>
        </Box>
      </Box>
      <Box style={styles.content}>
        <Box mb={15}>
          <Text>Home Address</Text>
          <Text variant='h5'>{user.address}</Text>
        </Box>
        <Box mb={15}>
          <Text>City</Text>
          <Text variant='h5'>{user.city}</Text>
        </Box>
        <Box mb={15}>
          <Text>Zip code</Text>
          <Text variant='h5'>{user.zip_code}</Text>
        </Box>
        <Box mb={15}>
          <Text>State</Text>
          <Text variant='h5'>{user.state}</Text>
        </Box>
        <Box mb={15}>
          <Text>Country</Text>
          <Text variant='h5'>{user.country}</Text>
        </Box>
        <Box style={styles.buttonWrapper}>
          <Button text='Edit account information' onPress={() => navigation.navigate('EditProfileScreen')} />
        </Box>
      </Box>
    </Screen>
  )
}

export default ProfileScreen

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  profileImageContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#F2F6FD'
  },
  profileImage: {
    height: 70,
    width: 70,
    borderRadius: 35,
    marginRight: 16,
  },
  content: {
    flex: 1,
    backgroundColor: '#ffff',
    padding: 16,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingVertical: 30
  },
  buttonWrapper: {
    flex: 1,
    justifyContent: 'flex-end'
  },
  imageContainer: {
    position: 'relative'
  },
  editBtn: {
    position: 'absolute',
    right: 12,
    bottom: 0,
    padding: 6,
    backgroundColor: '#e2e2e2',
    borderRadius: 20
  }
})
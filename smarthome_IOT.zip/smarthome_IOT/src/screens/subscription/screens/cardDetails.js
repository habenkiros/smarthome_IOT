import React, { useEffect, useState } from "react"
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Pressable,
  Alert
} from "react-native"
import FontAwesome from "react-native-vector-icons/FontAwesome"
import { useNavigation } from "@react-navigation/native"
import { Box, Button, TextField, Screen } from "components"
import { CardField, useStripe } from "@stripe/stripe-react-native"
import { scale, typography } from "utils"
import httpClient from "utils/httpClient"

const CardDetailsScreen = () => {
  const navigation = useNavigation()
  const [holderName, setHolderName] = useState("")
  const [cardOK, setCardOK] = useState(false)
  const [loading, setLoading] = useState(false)
  const { createToken } = useStripe()

  const _createToken = async () => {
    setLoading(true)
    const { error, token } = await createToken({
      type: "Card",
      name: holderName,
      currency: "usd"
    })

    if (error) {
      Alert.alert(`Error code: ${error.code}`, error.message)
      console.log(`Error: ${JSON.stringify(error)}`)
    } else if (token) {
      // Alert.alert(
      //   "Success",
      //   `The token was created successfully! token: ${token.id}`
      // )
      let result = await httpClient.post("/api/subscriptions/payment_method/",{
        token:token.id
      });
      Alert.alert(
        "Success",
        `Card successfully added!`
      )
      console.log(result.data)
      navigation.goBack();
    }
    setLoading(false)
  }

  return (
    <View style={styles.container}>
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>Add Card</Text>
        <Box mt={10}>
          <Box mv={10}>
            <TextField
              label="Card holder name"
              placeholder="Enter your card holder name"
              textColor="#1F1F1F"
              onChangeText={setHolderName}
            />
          </Box>
          <Box mv={10}>
            <Text variant="label" color={"#1F1F1F"} style={styles.label}>
              Card details
            </Text>
            <CardField
              postalCodeEnabled={false}
              placeholders={{
                number: "4242 4242 4242 4242"
              }}
              cardStyle={{
                backgroundColor: "#FFFFFF",
                textColor: "#000000"
              }}
              style={{
                width: "100%",
                height: 50
              }}
              onCardChange={cardDetails => {
                console.log("cardDetails", cardDetails)
                setCardOK(cardDetails?.complete)
              }}
              onFocus={focusedField => {
                console.log("focusField", focusedField)
              }}
            />
          </Box>
        </Box>
      </View>
      <View>
        <Button
          text="Confirm card details"
          disabled={!cardOK || !holderName}
          onPress={() => _createToken()}
          loading={loading}
        />
      </View>
    </View>
  )
}
export default CardDetailsScreen
const styles = StyleSheet.create({
  price: {
    fontFamily: "Gordita",
    fontSize: 29,
    fontWeight: "700",
    color: "#1F1F1F"
  },
  line: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 3
  },
  period: {
    fontFamily: "Gordita",
    fontSize: 19,
    fontWeight: "400",
    color: "#1F1F1F",
    paddingLeft: 10
  },
  radioInner: {
    width: 14,
    height: 14,
    backgroundColor: "#A4845B",
    borderRadius: 10,
    marginLeft: 2,
    marginTop: 2
  },
  radioOutter: {
    borderWidth: 1,
    width: 20,
    height: 20,
    borderRadius: 10,
    borderColor: "#A4845B",
    marginRight: 10
  },
  subContainer: {
    paddingHorizontal: 17,
    marginVertical: 5
  },
  title: {
    fontFamily: "Gordita",
    fontSize: 24,
    fontWeight: "700",
    marginBottom: 20
  },
  container: {
    flex: 1,
    backgroundColor: "white",
    paddingHorizontal: 18,
    paddingBottom: 10
  },
  label: {
    fontFamily: typography.regular_400,
    fontSize: scale(16),
    lineHeight: scale(18),
    letterSpacing: scale(-0.165)
  }
})

import React, { useEffect, useState } from "react"
import { View, Text, StyleSheet, FlatList, Pressable } from "react-native"
import FontAwesome from "react-native-vector-icons/FontAwesome"
import { Button } from "components"
import { useNavigation } from "@react-navigation/native"
import { useIAP, withIAPContext } from "react-native-iap"
import httpClient from "utils/httpClient"
import { useIsFocused } from "@react-navigation/native"

const dummy = [
  {
    id: "APPLEPAY",
    title: "Apple Pay",
    icon: <FontAwesome name="apple" size={22} color="#000" />
  },
  {
    id: "ADDCARD",
    title: "Add new credit Card",
    icon: <FontAwesome name="credit-card" size={22} color="#000" />
  }
]
const PaymentMethodScreen = ({ route }) => {
  const { sub, period } = route.params
  const isFocused = useIsFocused()
  const navigation = useNavigation()
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState()
  const [addedCards, setAddedCards] = useState([])
  const {
    getSubscriptions,
    requestSubscription
  } = useIAP()
  const doApplePay = async sku => {
    //  alert("ok");
    let productsa = await getSubscriptions({ skus: ["5_monthly", "5_yearly"] })
    console.log(productsa)

    let result = await requestSubscription({ sku: sku })
    console.log(result)
    // let resultAuth = await dispatch.auth.login({ email: auth.email, password: auth.password })
    // storeAccessToken(resultAuth.data.key)
    // let resultIAP = dispatch.auth.applePay({
    //   ...result,
    //   environment:"sandbox"
    // });
    // console.log(resultIAP);
    // dispatch.auth.loginSuccess(resultAuth.data)
    // SimpleToast.show("Registration success!")
  }
  const RenderItem = ({ item, isRegistredCard }) => {
    return (
      <Pressable
        style={styles.subContainer}
        onPress={() => setSelectedPaymentMethod(item.id)}
      >
        <View style={styles.line}>
          <View style={styles.radioOutter}>
            {selectedPaymentMethod === item.id && (
              <View style={styles.radioInner} />
            )}
          </View>
          {!isRegistredCard ? (
            item.icon
          ) : (
            <FontAwesome name="credit-card" size={22} color="#000" />
          )}
          {!isRegistredCard ? (
            <Text style={styles.period}>{item.title}</Text>
          ) : (
            <View style={{ flexDirection: "column" }}>
              <Text style={styles.period}>Credit card</Text>
              <Text style={styles.periodSub}>XXXX XXXX XXXX {item.last4}</Text>
            </View>
          )}
        </View>
      </Pressable>
    )
  }
  const doPayment = async () => {
    if (Number.isInteger(selectedPaymentMethod)) {
      alert("Payment method selected!")
      navigation.goBack()
      return false
    }
    if (selectedPaymentMethod === "APPLEPAY") {
      let sku = sub.id + "_" + period
      doApplePay(sku)
    }
    if (selectedPaymentMethod === "ADDCARD") {
      navigation.navigate("CardDetailsScreen")
    }
  }

  const getData = async () => {
    let result = await httpClient.get("/api/subscriptions/payment_method/")
    setAddedCards(result.data)
  }
  useEffect(() => {
    if (isFocused) {
      alert("here")
      getData()
    }
  }, [isFocused])
  return (
    <View style={styles.container}>
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>Select Payment Mode</Text>
        <RenderItem item={dummy[0]} />
        <FlatList
          style={{ flexGrow: 0 }}
          data={addedCards}
          renderItem={({ item }) => (
            <RenderItem item={item} isRegistredCard={true} />
          )}
          scrollEnabled={false}
        />
        <RenderItem item={dummy[1]} />
      </View>
      <View>
        <Button text="Confirm" onPress={doPayment} />
      </View>
    </View>
  )
}
export default withIAPContext(PaymentMethodScreen)
const styles = StyleSheet.create({
  price: {
    fontFamily: "Gordita",
    fontSize: 29,
    fontWeight: "700",
    color: "#1F1F1F"
  },
  line: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 3
  },
  period: {
    fontFamily: "Gordita",
    fontSize: 19,
    fontWeight: "400",
    color: "#1F1F1F",
    paddingLeft: 10
  },
  periodSub: {
    fontFamily: "Gordita",
    fontSize: 15,
    fontWeight: "400",
    color: "#1F1F1F",
    paddingLeft: 10
  },
  radioInner: {
    width: 14,
    height: 14,
    backgroundColor: "#A4845B",
    borderRadius: 10,
    marginLeft: 2,
    marginTop: 2
  },
  radioOutter: {
    borderWidth: 1,
    width: 20,
    height: 20,
    borderRadius: 10,
    borderColor: "#A4845B",
    marginRight: 10
  },
  subContainer: {
    paddingHorizontal: 17,
    marginVertical: 5
  },
  title: {
    fontFamily: "Gordita",
    fontSize: 24,
    fontWeight: "700",
    marginBottom: 20
  },
  container: {
    flex: 1,
    backgroundColor: "white",
    paddingHorizontal: 18,
    paddingBottom: 10
  }
})

import React, { useEffect, useState } from "react"
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Pressable,
  Image,
  Modal
} from "react-native"
import { Button } from "components"
import { useNavigation } from "@react-navigation/native"
import httpClient from "utils/httpClient"


const SubscriptionScreen = () => {
  const navigation = useNavigation()
  const [selectedSub, setSelectedSub] = useState(null)
  const [selectedPeriod, setSelectedPeriod] = useState("monthly")
  const [counter, setCounter] = useState(1)
  const [data, setData] = useState([])
  const [loading, setloading] = useState(true)
  const [modalVisible, setModalVisible] = useState(false)

  useEffect(() => {
    if (counter <= 0) {
      setCounter(1)
    }
  }, [counter])
  const getData = async () => {
    let result = await httpClient.get("/api/subscriptions/plans/")
    setData(result.data)
    setSelectedSub(result.data[0])
    setloading(false)
  }
  useEffect(() => {
    getData()
  }, [])
  if (loading) return <></>
  return (
    <View style={styles.container}>
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>Select Rentals Units</Text>
        <Pressable
          style={[styles.subContainer, { marginBottom: 30 }]}
          onPress={() => setModalVisible(true)}
        >
          <View style={styles.subTypeContainer}>
            <Image
              source={require("../../../assets/images/subscription.png")}
            />
            <Text style={styles.subName}>{selectedSub.name}</Text>
            <Text style={styles.subModify}>Modify</Text>
            <Image source={require("../../../assets/images/arrowDown.png")} />
          </View>
        </Pressable>
        <Text style={styles.title}>Subscriptions</Text>

        <Pressable
          style={styles.subContainer}
          onPress={() => setSelectedPeriod("monthly")}
        >
          <View style={styles.line}>
            <View style={styles.radioOutter}>
              {selectedPeriod === "monthly" && (
                <View style={styles.radioInner} />
              )}
            </View>
            <Text style={styles.period}>Monthly</Text>
            <Text style={styles.commercial}>1st Month free</Text>
          </View>
          <View style={styles.line}>
            <Text style={styles.price}>${selectedSub.monthly_price}</Text>
            <Text style={styles.save}>Save ${selectedSub.monthly_price}</Text>
          </View>
        </Pressable>

        <Pressable
          style={styles.subContainer}
          onPress={() => setSelectedPeriod("yearly")}
        >
          <View style={styles.line}>
            <View style={styles.radioOutter}>
              {selectedPeriod === "yearly" && (
                <View style={styles.radioInner} />
              )}
            </View>
            <Text style={styles.period}>Yearly</Text>
            <Text style={styles.commercial}>
              {selectedSub.yearly_discount}% Discount
            </Text>
          </View>
          <View style={styles.line}>
            <Text style={styles.price}>
              $
              {((selectedSub.monthly_price * 12) / 100) *
                (100 - selectedSub.yearly_discount)}
            </Text>
            <Text style={styles.priceCompare}>
              ${selectedSub.monthly_price * 12}
            </Text>
            <Text style={styles.save}>
              Save $
              {((selectedSub.monthly_price * 12) / 100) *
                selectedSub.yearly_discount}
            </Text>
          </View>
        </Pressable>
      </View>
      <View>
        <Text style={{ paddingBottom: 20 }}>
          The subscription charge is applied per number of unit, to add more
          units in future please cancel the current subscription and edit the
          number of units
        </Text>
        <Button
          text="Upgrade to premium"
          onPress={() => navigation.navigate("PaymentMethodScreen",{sub:selectedSub, period:selectedPeriod})}
        />
      </View>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(!modalVisible)
        }}
      >
        <Pressable
          style={styles.modalBackground}
          onPress={() => setModalVisible(!modalVisible)}
        >
          <View style={styles.modalContent}>
            <FlatList
              data={data}
              renderItem={({ item }) => {
                return (
                  <Pressable
                    onPress={() => {
                      setSelectedSub(item)
                      setModalVisible(false)
                    }}
                  >
                    <Text style={styles.modalItem}>{item.name}</Text>
                  </Pressable>
                )
              }}
            />
          </View>
        </Pressable>
      </Modal>
    </View>
  )
}
export default SubscriptionScreen
const styles = StyleSheet.create({
  modalItem: {
    fontSize: 19,
    fontWeight: "700",
    paddingVertical: 10,
    paddingLeft: 20,
    borderBottomColor: "#D9D8D8",
    borderBottomWidth: 1
  },
  modalContent: {
    backgroundColor: "white",
    marginHorizontal: 30,
    borderRadius: 10,
    paddingVertical: 10
  },
  modalBackground: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center"
  },
  subTypeContainer: {
    flexDirection: "row",
    alignItems: "center"
  },
  subModify: {
    color: "#A4845B",
    fontSize: 13,
    fontWeight: "500",
    paddingRight: 10
  },
  subName: {
    fontSize: 19,
    flex: 1,
    fontWeight: "700",
    paddingLeft: 10
  },
  counterText: {
    height: 55,
    lineHeight: 55,
    fontSize: 16,
    borderWidth: 1,
    borderRadius: 16,
    borderColor: "#D9D8D8",
    paddingHorizontal: 40,
    marginHorizontal: 10
  },
  counterContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20
  },
  counterBtn: {
    width: 55,
    height: 55,
    backgroundColor: "#A4845B",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 16
  },
  price: {
    fontFamily: "Gordita",
    fontSize: 29,
    fontWeight: "700",
    color: "#1F1F1F"
  },
  save: {
    fontFamily: "Gordita",
    fontSize: 15,
    fontWeight: "400",
    color: "#1F1F1F",
    textAlign: "right",
    flex: 1
  },
  priceCompare: {
    fontFamily: "Gordita",
    fontSize: 19,
    fontWeight: "400",
    color: "#1F1F1F",
    paddingLeft: 10,
    textDecorationLine: "line-through",
    textDecorationStyle: "solid"
  },
  line: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 3
  },
  commercial: {
    color: "#A4845B",
    textAlign: "right",
    flex: 1,
    fontFamily: "Gordita",
    fontSize: 16,
    fontWeight: "700"
  },
  period: {
    fontFamily: "Gordita",
    fontSize: 19,
    fontWeight: "400",
    color: "#1F1F1F",
    paddingLeft: 10
  },
  radioInner: {
    width: 14,
    height: 14,
    backgroundColor: "#A4845B",
    borderRadius: 10,
    marginLeft: 2,
    marginTop: 2
  },
  radioOutter: {
    borderWidth: 1,
    width: 20,
    height: 20,
    borderRadius: 10,
    borderColor: "#A4845B"
  },
  subContainer: {
    borderWidth: 1,
    borderColor: "#D9D8D8",
    borderRadius: 10,
    padding: 17,
    marginVertical: 10
  },
  title: {
    fontFamily: "Gordita",
    fontSize: 24,
    fontWeight: "700"
  },
  container: {
    flex: 1,
    backgroundColor: "white",
    paddingHorizontal: 18,
    paddingBottom: 10
  }
})

import { Pressable, StyleSheet } from 'react-native'
import React, { useEffect } from 'react'
import { Screen, Box, Text } from 'components'
import AntDesign from 'react-native-vector-icons/AntDesign'
import { getDevices } from 'screens/dashboard/store'
import { useDispatch, useSelector } from 'react-redux'
import AddedDevices from 'screens/dashboard/components/added-devices'

const DevicesScreen = ({}) => {
  const devices = useSelector(state => state.dashboard.devices)
  const dispatch = useDispatch()

  useEffect(() => {
    dispatch(getDevices())
  }, [])

  return (
    <Screen preset='scroll' unsafe={true}>
      <Box style={styles.container}>
        <Box style={styles.deviceContentTitle}>
          <Text variant='h3'>Devices</Text>
          <Pressable>
            <Box style={styles.row}>
              <AntDesign name='plus' size={20} />
              <Text> Add new device</Text>
            </Box>
          </Pressable>
        </Box>
        <Box>
          {
            devices?.map(d => <AddedDevices key={d.id} device={d} />)
          }
        </Box>
      </Box>
    </Screen>
  )
}

export default DevicesScreen

const styles = StyleSheet.create({
  container: {
    padding: 16,
    flex: 1,
  },
  deviceContentTitle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  row: {
    flexDirection: 'row'
  },
  content: {
    backgroundColor: '#ffff',
    borderRadius: 16,
    padding: 16,
    marginTop: 16,
    marginBottom: 24
  },
  deviceContentTitle: {
    paddingBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
})
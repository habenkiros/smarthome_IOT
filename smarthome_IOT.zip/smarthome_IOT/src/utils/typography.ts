export const typography = {
  thin_100: 'Gordita-Light',
  regular_400: 'Gordita-Regular',
  medium_600: 'Gordita-Medium',
  bold_700: 'Gordita-Bold',
};

export const palette = {
  black: '#1d1d1d',
  white: '#ffffff',
  offWhite: '#e6e6e6',
  angry: '#dd3333',
  darkGray: '#888888',
  primary: '#A4845B',
  appBackground: '#D2B48C',
  text: '#1F1F1F',
};

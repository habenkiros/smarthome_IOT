import React from 'react'
import { Header as RnHeader } from '@react-navigation/elements';
import { Image, Pressable, StyleSheet } from 'react-native';
import { color } from 'utils';

export const Header = ({ ...props }) => (
  <RnHeader
    headerShadowVisible={false}
    headerStyle={{
      backgroundColor: color.primaryLine,
    }}
    {...props}
  />
)

export const HeaderLeftButton = ({ navigation }) => (
  <Pressable
    style={styles.drawerButton}
    onPress={() => navigation.canGoBack() ? navigation.goBack() : navigation.toggleDrawer()}>
    {
      navigation.canGoBack() ?
        <Image source={require("assets/images/back.png")} /> :
        <Image source={require("assets/images/drawer-icon.png")} />
    }
  </Pressable>
)

const styles = StyleSheet.create({
  drawerButton: {
    borderWidth: 1,
    padding: 8,
    marginLeft: 16,
    marginRight: 22,
    marginVertical: 12,
    resizeMode: 'contain',
    borderRadius: 10,
    height: 40,
    width: 40
  }
})
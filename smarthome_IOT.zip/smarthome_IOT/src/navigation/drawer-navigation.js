import React from 'react'
import { createDrawerNavigator, } from '@react-navigation/drawer';
import DevicesScreen from 'screens/devices'
import CustomDrawer from 'components/custom-drawer';
import FeatherIcon from 'react-native-vector-icons/Feather'
import IoniconsIcon from 'react-native-vector-icons/Ionicons'
import AntDesign from 'react-native-vector-icons/AntDesign'
import DashboardNavigation from './dashboard-navigation';
import ProfileNavigation from './profile-navigation';
import DeviceNavigation from './device-navigation';
import SubscriptionNavigation from './subscription-navigation';

const Drawer = createDrawerNavigator();

const DrawerNavigation = () => {
  return (
    <Drawer.Navigator
      drawerContent={props => <CustomDrawer {...props} />}
      screenOptions={{
        headerShown: false,
      }}
    >
      <Drawer.Screen
        name="Dashboard"
        component={DashboardNavigation}
        options={{
          drawerIcon: () => <FeatherIcon name='box' size={24} />,
          drawerLabel: 'Dashboard Screen',
          title: 'Dashboard',
        }}
      />
      <Drawer.Screen
        name="ProfileScreen"
        component={ProfileNavigation}
        options={{
          drawerIcon: () => <FeatherIcon name='user' size={24} />,
          drawerLabel: 'My Profile'
        }}
      />
      <Drawer.Screen
        name="DevicesScreen"
        component={DeviceNavigation}
        options={{
          drawerIcon: () => <IoniconsIcon name='flashlight-outline' size={24} />,
          drawerLabel: 'Devices'
        }}
      />
      <Drawer.Screen
        name="NotificationScreen"
        component={ProfileNavigation}
        options={{
          drawerIcon: () => <IoniconsIcon name='notifications-outline' size={24} />,
          drawerLabel: 'Notifications'
        }}
      />
      <Drawer.Screen
        name="AboutAppScreen"
        component={ProfileNavigation}
        options={{
          drawerIcon: () => <IoniconsIcon name='book-outline' size={24} />,
          drawerLabel: 'About App'
        }}
      />
      <Drawer.Screen
        name="FeedbackScreen"
        component={ProfileNavigation}
        options={{
          drawerIcon: () => <AntDesign name='questioncircleo' size={24} />,
          drawerLabel: 'Send Feedback'
        }}
      />
        <Drawer.Screen
        name="SubscriptionNavigation"
        component={SubscriptionNavigation}
        options={{
          drawerIcon: () => <AntDesign name='questioncircleo' size={24} />,
          drawerLabel: 'Subscription'
        }}
      />
    </Drawer.Navigator>
  )
}

export default DrawerNavigation


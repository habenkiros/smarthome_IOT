import { createStackNavigator } from '@react-navigation/stack'
import { HeaderLeftButton } from 'components'
import React from 'react'
import DashboardScreen from 'screens/dashboard/screens'
import AddBookingScreen from 'screens/dashboard/screens/add-booking'
import AddUnitScreen from 'screens/dashboard/screens/add-unit'
import UnitViewScreen from 'screens/dashboard/screens/unit-view'
import { color } from 'utils'

const Stack = createStackNavigator()

const DashboardNavigation = () => (
  <Stack.Navigator
    initialRouteName='DashboardScreen'
    screenOptions={({ navigation }) => ({
      headerLeft: () => <HeaderLeftButton navigation={navigation} />,
      headerShadowVisible: false,
      headerStyle: {
        backgroundColor: color.white
      },
    })}>
    <Stack.Screen
      name="DashboardScreen"
      component={DashboardScreen}
      options={{
        title: 'Dashboard'
      }}
    />
    <Stack.Screen
      name="AddUnitScreen"
      component={AddUnitScreen}
      options={{
        title: 'Unit'
      }}
    />
    <Stack.Screen
      name="AddBookingScreen"
      component={AddBookingScreen}
      options={{
        title: 'Booking'
      }}
    />
    <Stack.Screen
      name="UnitViewScreen"
      component={UnitViewScreen}
      options={{
        title: ''
      }}
    />
  </Stack.Navigator>
)

export default DashboardNavigation
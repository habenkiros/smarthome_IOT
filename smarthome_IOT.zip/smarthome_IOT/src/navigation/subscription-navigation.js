import { createStackNavigator } from "@react-navigation/stack"
import { HeaderLeftButton } from "components"
import React from "react"
import SubscriptionScreen from "screens/subscription/screens"
import CardDetailsScreen from "screens/subscription/screens/cardDetails"
import PaymentMethodScreen from "screens/subscription/screens/paymentMethod"
import { color } from "utils"

const Stack = createStackNavigator()

const SubscriptionNavigation = () => (
  <Stack.Navigator
    initialRouteName="SubscriptionScreen"
    screenOptions={({ navigation }) => ({
      headerLeft: () => <HeaderLeftButton navigation={navigation} />,
      headerShadowVisible: false,
      headerStyle: {
        backgroundColor: color.white
      }
    })}
  >
    <Stack.Screen
      name="SubscriptionScreen"
      component={SubscriptionScreen}
      options={{
        title: ""
      }}
    />
    <Stack.Screen
      name="PaymentMethodScreen"
      component={PaymentMethodScreen}
      options={{
        title: ""
      }}
    />
    <Stack.Screen
      name="CardDetailsScreen"
      component={CardDetailsScreen}
      options={{
        title: ""
      }}
    />
  </Stack.Navigator>
)

export default SubscriptionNavigation

import { createStackNavigator } from '@react-navigation/stack'
import { HeaderLeftButton } from 'components'
import React from 'react'
import ProfileScreen from 'screens/profile/screens/profile'
import EditProfileScreen from 'screens/profile/screens/edit'
import { color } from 'utils'

const Stack = createStackNavigator()

const ProfileNavigation = () => (
  <Stack.Navigator screenOptions={({ navigation }) => ({
    headerLeft: () => <HeaderLeftButton navigation={navigation} />,
    headerShadowVisible: false,
    headerStyle: {
      backgroundColor: '#ffff'
    },
  })}>
    <Stack.Screen
      name="ProfileScreen"
      component={ProfileScreen}
      options={{
        title: '',
        headerStyle: {
          backgroundColor: '#F2F6FD'
        }
      }}
    />
    <Stack.Screen
      name="EditProfileScreen"
      component={EditProfileScreen}
      options={{
        title: '',
      }}
    />
  </Stack.Navigator>
)

export default ProfileNavigation
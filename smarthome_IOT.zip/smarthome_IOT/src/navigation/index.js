import React, { useEffect } from 'react'
import { DefaultTheme, NavigationContainer } from "@react-navigation/native"
import { createStackNavigator } from "@react-navigation/stack"
import SplashScreen from 'screens/splash'
import SignInScreen from 'screens/auth/screens/signin'
import SignUpScreen from 'screens/auth/screens/signup'
import ForgotPassword from 'screens/auth/screens/forgot-password'
import DrawerNavigation from './drawer-navigation'
import { color } from 'utils'
import { useSelector, useDispatch } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { setAuthToken } from 'utils/httpClient'
import { getAuthUser } from 'screens/auth/store'
import OtpScreen from 'screens/auth/screens/otp'
import UpdatePassword from 'screens/auth/screens/update-password'

const Stack = createStackNavigator()

const Navigation = () => {
  const user = useSelector((state) => state.auth.user);
  const dispatch = useDispatch();

  useEffect(() => {
    (async () => {
      let token = await AsyncStorage.getItem("@token")
      if (token) {
        setAuthToken(JSON.parse(token))
        dispatch(getAuthUser(JSON.parse(token)))
      }
    })();
  }, []);

  return (
    <NavigationContainer theme={{
      ...DefaultTheme,
      colors: {
        ...DefaultTheme.colors,
        background: color.palette.background,
      },
    }}>
      <Stack.Navigator screenOptions={{
        headerShown: false
      }}
        initialRouteName='SplashScreen'
      >
        {
          !user?.id ?
            <>
              <Stack.Screen name="SplashScreen" component={SplashScreen} />
              <Stack.Screen name="SignInScreen" component={SignInScreen} />
              <Stack.Screen name="SignUpScreen" component={SignUpScreen} />
              <Stack.Screen name="ForgotPassword" component={ForgotPassword} />
              <Stack.Screen name="OtpScreen" component={OtpScreen} />
              <Stack.Screen name="UpdatePassword" component={UpdatePassword} />
            </> :
            <Stack.Screen name="App" component={DrawerNavigation} />
        }
      </Stack.Navigator>
    </NavigationContainer>
  )
}

export default Navigation

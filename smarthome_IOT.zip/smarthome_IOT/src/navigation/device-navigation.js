import { createStackNavigator } from '@react-navigation/stack'
import { HeaderLeftButton } from 'components'
import React from 'react'
import { color } from 'utils'
import DevicesScreen from 'screens/devices'

const Stack = createStackNavigator()

const DeviceNavigation = () => (
  <Stack.Navigator screenOptions={({ navigation }) => ({
    headerLeft: () => <HeaderLeftButton navigation={navigation} />,
    headerShadowVisible: false,
    headerStyle: {
      backgroundColor: color.white
    },
  })}>
    <Stack.Screen
      name="DevicesScreen"
      component={DevicesScreen}
      options={{
        title: ''
      }}
    />

  </Stack.Navigator>
)

export default DeviceNavigation
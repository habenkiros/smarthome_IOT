import { configureStore, createReducer, combineReducers } from "@reduxjs/toolkit"
import { authSlice, initialAuthState } from 'screens/auth/store'
import { dashboardSlice, initialDashboardState } from 'screens/dashboard/store'


export const getStore = (globalState) => {
  const appReducer = createReducer(globalState, _ => {
    return globalState
  })

  const reducer = combineReducers({
    app: appReducer,
    auth: authSlice.reducer,
    dashboard: dashboardSlice.reducer
  })

  const rootReducer = (rootState, action) => {
    if (action.type === 'login/logoutRequest/fulfilled') {
      if (rootState) {
        rootState = {
          ...rootState,
          auth: initialAuthState,
          dashboard: initialDashboardState
        }
      }
    }
    return reducer(rootState, action);
  };

  return configureStore({
    reducer: rootReducer,
    middleware: getDefaultMiddleware => getDefaultMiddleware()
  })
}
import React from "react"
import opts from "./../modules/*/options.js";

import { modulesOptions, globalOptions } from "./options"

let options = {}

opts.map(opt => {
  options[opt.package] = opt.value
})


export function getOptions(pakage) {
  let target = options[pakage] || {}
  let source = modulesOptions[pakage] || {}
  return Object.assign(target, source)
}

export function getGlobalOptions() {
  return globalOptions
}

export const OptionsContext = React.createContext(options)
export const GlobalOptionsContext = React.createContext(globalOptions)

export const theme = {
  colors: {
    primary: '#A4845B',
    secondary: '#00AEC5',
    black: '#2D2935',
    white: '#FAFAFA',
    neutral: '#605E70'
  },
  CheckBox: {
    wrapperStyle: {
      padding: 0,
      paddingLeft: 0
    },
    containerStyle: {
      padding: 0,
    }
  },
  SearchBar: {
    inputContainerStyle: {
      backgroundColor: 'transparent',
      borderWidth: 1,
      borderBottomWidth: 1,
      borderColor: '#EDECF2',
      height: 48,
      borderRadius: 8
    },
    containerStyle: {
      backgroundColor: 'transparent',
      borderTopWidth: 0,
      borderBottomWidth: 0,
      paddingLeft: 0,
      paddingRight: 0
    }
  }
};


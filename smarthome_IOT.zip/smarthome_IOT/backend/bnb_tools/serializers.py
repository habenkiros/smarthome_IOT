from home.api.v1.serializers import UserSerializer
from django.contrib.auth import get_user_model
from adopter.sdk import SmartThings
from .models import (
    Booking,
    Devices,
    Support,
    Unit,
    Heater,
    SmartLock,
    SmartOutlet,
    SmartLight,
    Fan,
    Shutters,
    WaterHeater,
    SmokeDetector,
    SoundSystem,
    Gate,
    Vacuum,
    Sprinkler
)

from rest_framework import serializers
import json
from subscriptions.functions import sdk
from django.conf import settings
from bnb_tools.models import DeviceType
from django.contrib.auth import get_user_model

stripe_sdk = sdk(settings.STRIPE_SECRET_KEY)
User = get_user_model()

# token = '71fc6741-dca6-42e7-865c-9158bc1a3014'
# ST = SmartThings(token)

User = get_user_model()

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'email', 'first_name', 'last_name']

class SupportSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = Support
        fields = ['id', 'user', 'email', 'message']

    def create(self, validated_data):
        user = self.context['request'].user
        return Support.objects.create(user=user, **validated_data)


class DevicesWhileAddingUnitSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=50)
    device_type = serializers.CharField(max_length=50)
    location = serializers.CharField(max_length=50)
    status = serializers.CharField(max_length=50)
    capabilities = serializers.CharField(max_length=50)


class UnitSerializer(serializers.ModelSerializer):
    devices = serializers.SerializerMethodField('get_devices', read_only=True)
    image_encoded = serializers.CharField(write_only=True)

    class Meta:
        model = Unit
        fields = '__all__'
        extra_kwargs = {
            'image': {
                'read_only': True
            }
        }

    def get_devices(self, obj):
        all_devices = Devices.objects.filter(unit=obj)
        return DevicesSerializerInUnit(all_devices, many=True).data

class UnitCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Unit
        fields = ['user', 'name', 'number', 'address', 'city', 'zip_code', 'country', 'image', 'st_location_id']

class UserListLocationSerializer(serializers.ModelSerializer):
    locations = serializers.SerializerMethodField('get_locations', read_only=True)
    class Meta:
        model = User
        fields = ['id', 'locations']

    def get_locations(self, obj):
        all_units = Unit.objects.filter(user=obj.pk)
        return UnitSerializer(all_units, many=True).data

class DevicesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Devices
        fields = ['id', 'unit', 'name',
                  'location', 'device_type', 'status', 'capabilities']

class DevicesCreateSerializer(serializers.ModelSerializer):

    class Meta:
        model = Devices
        fields = ['unit', 'name', 'device_type',
                  'location', 'component_id', 
                  'device_id']


class DevicesSerializerInUnit(serializers.ModelSerializer):
    class Meta:
        model = Devices
        fields = ['id', 'name', 'location', 'device_type', 'device_id', 'status', 'capabilities']


class HeaterListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Heater
        fields = ['id', 'unit', 'name',
                  'location', 'device_type', 'status']

class HeaterCreateSerializer(serializers.ModelSerializer):
    unit = serializers.IntegerField()
    class Meta:
        model = Heater
        fields = ['unit', 'name', 'device_type',
                  'location', 'status']

class SmartLockListSerializer(serializers.ModelSerializer):
    class Meta:
        model = SmartLock
        fields = ['id', 'unit', 'name',
                  'location', 'device_type', 'status', 'lock', 'code']

class SmartLockCreateSerializer(serializers.ModelSerializer):
    unit = serializers.IntegerField()
    class Meta:
        model = SmartLock
        fields = ['unit', 'name',
                  'location', 'device_type', 'status']

class SmartOutletListSerializer(serializers.ModelSerializer):
    class Meta:
        model = SmartLock
        fields = ['id', 'unit', 'name',
                  'location', 'device_type', 'status', 'switch']

class SmartOutletCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = SmartLock
        fields = ['unit', 'name',
                  'location', 'device_type', 'status']

class SmartLightListSerializer(serializers.ModelSerializer):
    class Meta:
        model = SmartLight
        fields = ['id', 'unit', 'name',
                  'location', 'device_type', 'status', 'switch', 'level']


class SmartLightCreateSerializer(serializers.ModelSerializer):
    unit = serializers.IntegerField()
    class Meta:
        model = SmartLight
        fields = ['unit', 'name',
                  'location', 'device_type', 'status']


class FanListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Fan
        fields = ['id', 'unit', 'name',
                  'location', 'device_type', 'status', 'switch', 'level']

class FanCreateSerializer(serializers.ModelSerializer):
    unit = serializers.IntegerField()
    class Meta:
        model = Fan
        fields = ['unit', 'name', 'device_type',
                  'location',  'status']

class ShuttersListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Shutters
        fields = ['id', 'unit', 'name',
                  'location', 'device_type', 'status', 'windowShade', 'level']

class ShuttersCreateSerializer(serializers.ModelSerializer):
    unit = serializers.IntegerField()
    class Meta:
        model = Shutters
        fields = ['unit', 'name',
                  'location', 'device_type', 'status']

class WaterHeaterListSerializer(serializers.ModelSerializer):
    class Meta:
        model = WaterHeater
        fields = ['id', 'unit', 'name',
                  'location', 'device_type', 'status', 'switch', 'temperature']

class WaterHeaterCreateSerializer(serializers.ModelSerializer):
    unit = serializers.IntegerField()    
    class Meta:
        model = WaterHeater
        fields = ['unit', 'name',
                  'location', 'device_type', 'status']

class SmokeDetectorListSerializer(serializers.ModelSerializer):
    class Meta:
        model = SmokeDetector
        fields = ['id', 'unit', 'name',
                  'location', 'device_type', 'status', 'smoke', 'carbonMonoxide', 'push_notifications_enabled']

class SmokeDetectorCreateSerializer(serializers.ModelSerializer):
    unit = serializers.IntegerField()
    class Meta:
        model = SmokeDetector
        fields = ['unit', 'name',
                  'location', 'device_type', 'status']

class SoundSystemListSerializer(serializers.ModelSerializer):
    class Meta:
        model = SoundSystem
        fields = ['id', 'unit', 'name',
                  'location', 'device_type', 'status', 'switch', 'volume', 'mute']

class SoundSystemCreateSerializer(serializers.ModelSerializer):
    unit = serializers.IntegerField()
    class Meta:
        model = SoundSystem
        fields = ['unit', 'name',
                  'location', 'device_type', 'status']

class GateListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Gate
        fields = ['id', 'unit', 'name',
                  'location', 'device_type', 'status', 'lock', 'code']

class GateCreateSerializer(serializers.ModelSerializer):
    unit = serializers.IntegerField()
    class Meta:
        model = Gate
        fields = ['unit', 'name',
                  'location', 'device_type', 'status']

class VacuumListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vacuum
        fields = ['id', 'unit', 'name',
                  'location', 'device_type', 'status', 'switch', 'cleaningStatus']

class VacuumCreateSerializer(serializers.ModelSerializer):
    unit = serializers.IntegerField()
    class Meta:
        model = Vacuum
        fields = ['unit', 'name',
                  'location', 'device_type', 'status']

class SprinklerListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Sprinkler
        fields = ['id', 'unit', 'name',
                  'location', 'device_type', 'status', 'valve']

class SprinklerCreateSerializer(serializers.ModelSerializer):
    unit = serializers.IntegerField()
    class Meta:
        model = Sprinkler
        fields = ['unit', 'name',
                  'location', 'device_type', 'status']

class BookingSerializer(serializers.ModelSerializer):
    devices = serializers.ListField(
        child=serializers.CharField(), read_only=True)
    user = UserSerializer(read_only=True)
    unit_id = serializers.IntegerField(write_only=True)
    unit = UnitSerializer(read_only=True)

    class Meta:
        model = Booking
        fields = ['id', 'user', 'guest_name', 'guest_contact',
                  'arrival', 'departure', 'devices', 'unit_id', 'unit']

    def create(self, validated_data):
        user = self.context['request'].user
        return Booking.objects.create(user=user, **validated_data)

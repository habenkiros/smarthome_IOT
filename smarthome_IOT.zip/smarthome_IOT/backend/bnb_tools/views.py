from django.dispatch import receiver
from django_rest_passwordreset.signals import reset_password_token_created
from django.template.loader import render_to_string
from django.core.mail import EmailMultiAlternatives
from django.urls import reverse
from django.shortcuts import get_object_or_404
from django.contrib.auth import get_user_model
import logging
import json
# Create your views here.
from rest_framework.viewsets import ModelViewSet, GenericViewSet
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from rest_framework.decorators import action

from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.contrib.auth import get_user_model

from utils.functions import base64_file
from django.http import JsonResponse

from .permission import IsOwnerAndAuthenticated, UnitOwnerAndAuthenticated
from .commands import Commands

from adopter.sdk import SmartThings
from .permission import IsOwnerAndAuthenticated
# Social Media Sign in Sign up
from allauth.socialaccount.providers.facebook.views import FacebookOAuth2Adapter
from allauth.socialaccount.providers.oauth2.client import OAuth2Client
from dj_rest_auth.registration.views import SocialLoginView
from allauth.socialaccount.providers.google.views import GoogleOAuth2Adapter
from allauth.socialaccount.providers.apple.views import AppleOAuth2Adapter
from allauth.socialaccount.providers.apple.client import AppleOAuth2Client
from .serializers import (
    UserSerializer,
    BookingSerializer,
    DevicesSerializer,
    DevicesCreateSerializer,
    SupportSerializer,
    UnitSerializer,
    UnitCreateSerializer,
    UserListLocationSerializer,
    HeaterListSerializer,
    HeaterCreateSerializer,
    FanListSerializer,
    FanCreateSerializer,
    ShuttersListSerializer,
    ShuttersCreateSerializer,
    SmartLockListSerializer,
    SmartLockCreateSerializer,
    SmartOutletListSerializer,
    SmartOutletCreateSerializer,
    SmartLightListSerializer,
    SmartLightCreateSerializer,
    SmokeDetectorListSerializer,
    SmokeDetectorCreateSerializer,
    SoundSystemListSerializer,
    SoundSystemCreateSerializer,
    GateListSerializer,
    GateCreateSerializer,
    WaterHeaterListSerializer,
    WaterHeaterCreateSerializer,
    VacuumListSerializer,
    VacuumCreateSerializer,
    SprinklerListSerializer,
    SprinklerCreateSerializer

)
from home.api.v1.serializers import UserSerializer

from .models import (
    Support,
    Unit,
    Devices,
    Booking,
    DeviceType,
    Heater,
    Fan,
    Shutters,
    SmartLock,
    SmartOutlet,
    SmartLight,
    SmokeDetector,
    SoundSystem,
    Gate,
    WaterHeater,
    Vacuum,
    Sprinkler,
    DeviceType

)

# from utils.functions import (
#     connect_to_calendar,
#     prepare_event
# )


# token = '71fc6741-dca6-42e7-865c-9158bc1a3014'
# ST = SmartThings(token)

User = get_user_model()

class UserViewSet(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    serializer_class = UserSerializer
    queryset = User.objects.all()

    @action(detail=True, methods=['post'])
    def upload_photo(self, request, pk):
        file = request.FILES.get('image', False)

        if file:
            user = get_object_or_404(User, pk=pk)
        
            user.photo = file
            user.save()

            return Response(status=status.HTTP_201_CREATED)



class SupportViewset(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    serializer_class = SupportSerializer
    queryset = Support.objects.all()

class LogoutAPIView(APIView):
    permission_classes = (IsOwnerAndAuthenticated,)

    def post(self, request, format=None):
        request.user.auth_token.delete()
        return Response(status=status.HTTP_200_OK)


class UnitViewSet(ModelViewSet):

    permission_classes = (UnitOwnerAndAuthenticated, )
    serializer_class = UnitSerializer
    queryset = Unit.objects.all()

    def create(self, request, *args, **kwargs):
        st_token = request.user.st_token
        ST = SmartThings(st_token)

        new_unit = request.data
        new_unit['user'] = request.user.id
        image_b64 = request.data.get('image_encoded')
        new_unit['image'] = base64_file(image_b64)
        
        location = ST.create_location(new_unit['name'])
        location_id = json.loads(location.get('message')).get('locationId')
        new_unit['st_location_id'] = location_id

        # stripe_sdk.update_subscription(
        #     id=user.subscription_id, quantity=Unit.objects.filter(user=user).count())
        # Insert Unit ID to each device

        serializer = UnitCreateSerializer(data=new_unit)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data, status=status.HTTP_200_OK)

    @action(detail=True, methods=['post'])
    def create_devices(self, request, pk):
        unit = get_object_or_404(Unit, pk=pk)
        st_token = request.user.st_token
        ST = SmartThings(st_token)

        devices = request.data.get('devices')

        for device in devices:
            ST.create_device_in_location(device['name'], unit.st_location_id, device['device_type_id'])

            device['unit'] = unit.id
            device['component_id'] = 'main'
            serializer = DevicesCreateSerializer(data=device)
            serializer.is_valid(raise_exception=True)
            serializer.save()

        return Response(serializer.data, status=status.HTTP_200_OK)


    @action(detail=False, methods=['get'])
    def sync_locations(self, request, *args, **kwargs):
        st_token = request.user.st_token
        ST = SmartThings(st_token)

        try:
            locations = ST.get_location_list()
            user_locations = []
            user = UserSerializer(instance=request.user).data

            for location in locations['items']:

                unit, created = Unit.objects.get_or_create(
                    user=request.user,
                    name=location['name'],
                    st_location_id=location['locationId'])

                user_locations.append(unit)

            serializer = UnitSerializer(user_locations, many=True)
            
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Exception as e:
            logging.error(e)
            return Response({
                "message": "Error Syncing Locations"
            }, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'])
    def sync_devices(self, request, pk):
        st_token = request.user.st_token
        ST = SmartThings(st_token)
        
        unit = get_object_or_404(Unit, pk=pk)

        try:
            devices_list = ST.get_device_list({
                "locationId": unit.st_location_id
            })
            devices_to_add = []

            for device in devices_list['items']:
                devices_to_add.append(device)

            return JsonResponse(data={"devices_in_unit": devices_to_add}, status=200, safe=False)

                # response_device_type = device['components'][0]['categories'][0]['name']
                # if response_device_type == 'Light':
                #     device_type = DeviceType.SMARTLIGHT
                # else:
                #     device_type = None

            #     device_capabilities = {'capabilities': []}
            #     for capability in device['components'][0]['capabilities']:
            #         device_capabilities['capabilities'].append(capability['id'])

            #     device_obj, created = Devices.objects.get_or_create(
            #         unit_id=unit.id,
            #         name=device['name'],
            #         # device_type=device_type,
            #         location=device['locationId'],
            #         provider=device['manufacturerName'],
            #         component_id=device['components'][0]['id'],
            #         device_id=device['deviceId'],
            #         capabilities=device_capabilities
            #     )

            #     devices_to_add.append(device_obj)

            # serializer = UnitSerializer(instance=unit)

            # return Response(serializer.data, status=status.HTTP_200_OK)

        except Exception as e:
            logging.error(e)
            return Response({
                "message": "Error Syncing Devices"
            }, status=status.HTTP_400_BAD_REQUEST)
        
    # @action(detail=True, methods=["post"])
    # def toggle_all_off(self, request, pk):
    #     devices_in_unit = Devices.objects.filter(unit=pk)
    #     devices_in_unit.update(status='inactive')

    #     serializer = DevicesSerializer(devices_in_unit, many=True)

    #     return Response(serializer.data, status=status.HTTP_200_OK)


class DevicesViewSet(ModelViewSet):
    permission_classes = (IsOwnerAndAuthenticated, )
    serializer_class = DevicesSerializer
    queryset = Devices.objects.all()
    create_serializer_class = DevicesCreateSerializer
    device_type = None

    def get_create_serializer(self, *args, **kwargs):
        serializer_class = self.get_serializer_class()
        kwargs.setdefault('context', self.get_serializer_context())
        return serializer_class(*args, **kwargs)

    def get_create_serializer_class(self):
        return self.create_serializer_class

    # def create(self, request, *args, **kwargs):
    #     new_device = request.data
    #     new_device['device_type'] = self.device_type

    #     serializer = self.get_create_serializer(data=new_device)
    #     serializer.is_valid(raise_exception=True)
    #     serializer.save()

    #     device_id = serializer.data['device_id']
    #     data_for_update = {}
    #     device_components = ST.get_device(device_id)['components']
        
    #     for component in device_components:
    #         if component['id'] == 'main':
    #             device_capabilities = component['capabilities']
    #             data_for_update.update({'capabilities': device_capabilities})

    #     status = ST.get_status(device_id)
    #     data_for_update.update({'status': status})

    #     serializer(data=data_for_update, partial=True)

    #     return Response(serializer.data, status=status.HTTP_201_CREATED)

    def check_device_has_capability(self, device, capability):
        if capability in device.capabilities['capabilities']:
            return True
        
        return False

    # @action(detail=False, methods=["post"], url_path=r'command/(?P<device_id>\d+)')
    def command(self, st_token, device, device_command):
        ST = SmartThings(st_token)

        if device_command == None:
            return Response({
                "message": "Command is required"
            }, status=status.HTTP_400_BAD_REQUEST)

        if device == None:
            return Response({
                "message": "Device not not found"
            }, status=status.HTTP_404_NOT_FOUND)

        if device.device_id == None:
            return Response({
                "message": "Device not regsitered"
            }, status=status.HTTP_404_NOT_FOUND)

        # device_has_capability = self.check_device_has_capability(device, device_command['capability'])
        # if not device_has_capability:
        #     return Response({
        #         "message": "Device does not posses capability"
        #     }, status=status.HTTP_400_BAD_REQUEST) 

        command = ST.execute_command(
            device_id=device.device_id,
            component_id=device_command['component'],
            capability=device_command['capability'],
            command=device_command['command']
        )

        device_status = ST.get_status(device.device_id)['components']['main']
        device.status = device_status
        device.save()

        serializer = DevicesSerializer(instance=device)

        return Response(serializer.data, status=status.HTTP_200_OK)
        

    @action(detail=True, methods=["get"])
    def update_status(self, request, pk):
        device = self.get_queryset().get(pk=pk)

        device_status = ST.get_status(device.device_id)['components']['main']
        device.status = device_status

        device.save()

        serializer = DevicesSerializer(instance=device)

        return Response(serializer.data, status=status.HTTP_200_OK)

    @action(detail=True, methods=["get"])

    def toggle_on(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)        
        return self.command(st_token, device, Commands.TOGGLE_ON)

    @action(detail=True, methods=["get"])
    def toggle_off(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        return self.command(st_token, device, Commands.TOGGLE_OFF)

    # @action(detail=False, methods=["post"])
    # def toggle_all_off(self, request):
    #     st_token = request.user.st_token
    #     unit_id = request.data.get('unit_id')


    #     devices = self.get_queryset().filter(unit_id=unit_id)
        
    #     device_command = {
    #         "component": "main",
    #         "capability": "switch",
    #         "command": "off"
    #     }
    #     resp = []

    #     for device in devices:
    #         resp.append(self.command(st_token, device, device_command))

    #     serializer = DevicesSerializer(self.get_queryset())

    #     return Response(serializer.data, status=status.HTTP_200_OK)


    # Heater
    @action(detail=True, methods=["post"])
    def set_heat_temperature(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)

        device_command = Commands.SET_HEAT_TEMPERATURE
        arguments = {
            'value': request.data.get('temperature'),
            'unit': request.data.get('unit')
        }
        device_command['arguments'][0].update(arguments) 

        return self.command(st_token, device, device_command)
    
    @action(detail=True, methods=["post"])
    def set_cool_temperature(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)

        device_command = Commands.SET_COOL_TEMPERATURE
        arguments = {
            'value': request.data.get('temperature'),
            'unit': request.data.get('unit')
        }
        device_command['arguments'][0].update(arguments) 

        return self.command(st_token, device, device_command)

    @action(detail=True, methods=["get"])
    def toggle_heat(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        return self.command(st_token, device, Commands.TOGGLE_HEAT)
    
    @action(detail=True, methods=["get"])
    def toggle_cool(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        return self.command(st_token, device, Commands.TOGGLE_COOL)

    @action(detail=True, methods=["get"])
    def toggle_eco(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        return self.command(st_token, device, Commands.TOGGLE_ECO)

    @action(detail=True, methods=["get"])
    def toggle_fan_only(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        return self.command(st_token, device, Commands.TOGGLE_FAN_ONLY)

    # @action(detail=True, methods=["get"])
    # def toggle_purifier(self, request, pk):
    #     heater = get_object_or_404(Heater, pk=pk)
    #     heater.mode = 'purifier'

    #     heater.save()

    #     serializer = HeaterListSerializer(instance=heater)
    #     return Response(serializer.data, status=status.HTTP_200_OK)

    #     toggle_command = {
    #         "command": {
    #             "commands": [{
    #                 "component": "main",
    #                 "capability": "thermostatMode",
    #                 "command": "moistair",
    #             }]
    #         }
    #     }

    #     return self.command(toggle_command, heater)

    @action(detail=True, methods=["get"])
    def toggle_dry(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        return self.command(st_token, device, Commands.TOGGLE_DRY)

    # SmartLock
    @action(detail=True, methods=["get"])
    def lock(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        return self.command(st_token, device, Commands.LOCK)

    @action(detail=True, methods=["get"])
    def unlock(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        return self.command(st_token, device, Commands.UNLOCK)

    @action(detail=True, methods=["post"])
    def set_code(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        
        device_command = Commands.SET_CODE
        arguments = {
            'code': request.data.get('code'),
            'name': request.data.get('name') 
        }
        device_command['arguments'][0].update(arguments) 
        
        return self.command(st_token, device, device_command)

    # SmartLight
    @action(detail=True, methods=["post"])
    def set_brightness(self, request, pk):        
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        
        device_command = Commands.SET_BRIGHTNESS
        device_command['arguments'] = [request.data.get('brightness')]
        
        return self.command(st_token, device, device_command)

    # Fan
    @action(detail=True, methods=["post"])
    def set_speed(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        
        device_command = Commands.SET_SPEED
        device_command['arguments'] = [request.data.get('speed')]

        return self.command(st_token, device, device_command)

    # Shutters
    @action(detail=True, methods=["get"])
    def toggle_open(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        return self.command(st_token, device, Commands.TOGGLE_OPEN)

    @action(detail=True, methods=["get"])
    def toggle_close(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        return self.command(st_token, device, Commands.TOGGLE_CLOSE)

    @action(detail=True, methods=["post"])
    def set_level(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        
        device_command = Commands.SET_LEVEL
        device_command['arguments'] = [request.data.get('level')]
        
        return self.command(st_token, device, device_command)

    # Water Heater
    @action(detail=True, methods=["post"])
    def set_temperature(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        
        device_command = Commands.SET_WATER_TEMPERATURE
        arguments = {
            'temperature': request.data.get('temperature'),
            'unit': request.data.get('unit')
        }
        device_command['arguments'][0].update(arguments) 
        
        return self.command(st_token, device, device_command)

    # Smoke Detector
    @action(detail=True, methods=["get"])
    def toggle_notifications(self, request, pk, *args, **kwargs):
        device = get_object_or_404(Devices, pk=pk)

        # notification_command = {
        #     "if": {
        #         "trigger": {
        #             "type": "device",
        #             "deviceId": smoke_detector.device_id,
        #             "capability": "smokeDetector",
        #             "attribute": "smoke",
        #             "state": "detected"
        #         }
        #     },
        #     "then": {
        #         "command": {
        #             "notification": {
        #                 "type": "push",
        #                 "message": "Smoke detected at home",
        #                 "options": {
        #                     "sound": "default"
        #                 }
        #             }
        #         }
        #     }
        # }

        # return self.automation(notification_command, smoke_detector)

    # SoundSystem
    @action(detail=True, methods=["post"])
    def set_volume(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)

        device_command = Commands.SET_VOLUME
        device_command['arguments'] = [request.data.get('volume')]
        
        return self.command(st_token, device, device_command)

    @action(detail=True, methods=["get"])
    def mute(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        return self.command(st_token, device, Commands.MUTE)
    
    @action(detail=True, methods=["get"])
    def unmute(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        return self.command(st_token, device, Commands.UNMUTE)

    # Vacuum
    @action(detail=True, methods=["get"])
    def toggle_energy_storage(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        return self.command(st_token, device, Commands.DOCK)

    @action(detail=True, methods=["post"])
    def run_cycle(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)
        return self.command(st_token, device, Commands.RUN_CYCLE)

    # Sprinkler
    @action(detail=True, methods=["post"])
    def set_timer(self, request, pk):
        st_token = request.user.st_token
        device = get_object_or_404(Devices, pk=pk)

        # time_delay = request.data.get('time_delay')

        # device_command = {
        #     "actions": [
        #         {
        #             "delay": {
        #                 "minutes": time_delay
        #             },
        #             "then": {
        #                 "commands": [
        #                     {
        #                         "component": "main",
        #                         "capability": "valve",
        #                         "command": "on"
        #                     }
        #                 ]
        #             }
        #         }
        #     ]
        # }

        # return self.automation(st_token, device, device_command)
        
class BookingViewSet(ModelViewSet):
    permission_classes = (IsOwnerAndAuthenticated,)
    serializer_class = BookingSerializer
    queryset = Booking.objects.all()

    # def perform_create(self, request):
    #     # This function connects us to google calendar
    #     service = connect_to_calendar(request=request)

    #     # the prepare_event takes the validated_data and provide us the JSOn version to be sent the google calendar
    #     event = prepare_event(self.validated_data)

    #     # adding event to the google calendar

    #     created_event = service.events().insert(
    #         calendarId='primary', sendNotifications=True, body=event).execute()


@receiver(reset_password_token_created)
def password_reset_token_created(sender, instance, reset_password_token, *args, **kwargs):
    # send an e-mail to the user
    context = {
        'current_user': reset_password_token.user,
        'username': reset_password_token.user.username,
        'email': reset_password_token.user.email,
        'reset_password_url': "{}?token={}".format(
            instance.request.build_absolute_uri(
                reverse('password_reset:reset-password-confirm')),
            reset_password_token.key),
        'reset_token': reset_password_token.key
    }

    # render email text
    email_html_message = render_to_string(
        'email/user_reset_password.html', context)
    email_plaintext_message = render_to_string(
        'email/user_reset_password.txt', context)

    msg = EmailMultiAlternatives(
        # title:
        "Password Reset for {title}".format(title="BNB TOOLS"),
        # message:
        email_plaintext_message,
        # from:
        "swornim.shrestha@crowdbotics.com",
        # to:
        [reset_password_token.user.email]
    )
    msg.attach_alternative(email_html_message, "text/html")
    msg.send()


class FacebookLogin(SocialLoginView):
    adapter_class = FacebookOAuth2Adapter
    client_class = OAuth2Client


class GoogleLogin(SocialLoginView):  # if you want to use Implicit Grant, use this
    adapter_class = GoogleOAuth2Adapter
    client_class = OAuth2Client
    callback_url = 'http://localhost:8000/api/auth/google/'


class AppleLogin(SocialLoginView):
    adapter_class = AppleOAuth2Adapter
    client_class = AppleOAuth2Client
    callback_url = 'localhost:8000'

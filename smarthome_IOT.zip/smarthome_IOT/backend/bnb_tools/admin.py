from django.contrib import admin
from bnb_tools.forms import ResponseForm
from bnb_tools.models import Support
from django.utils.html import format_html
from django.urls import path, reverse
from django.shortcuts import redirect
from django.core.mail import send_mail
from django.shortcuts import render

from .models import Unit, Booking, Devices

class SupportAdmin(admin.ModelAdmin):
    list_display = ('user', 'email', 'message', 'respond_action')

    def respond_feedback(self, request, pk):
        feedback = self.get_object(request, pk)

        if request.method != 'POST':
            form = ResponseForm()
        else:
            form = ResponseForm(request.POST)
            if form.is_valid():
                message = form.cleaned_data['message']
                message = 'Our Response: ' + message
                send_mail("We heard you - Response to your feedback - BNB Tools", message, 'swornim.shrestha@crowdbotics.com', [
                          feedback.user.email], fail_silently=False)

                self.message_user(request, 'Success')
                url = reverse(
                    'admin:bnb_tools_support_changelist',
                    current_app=self.admin_site.name,
                )
                return redirect(url)

        context = {}
        context['form'] = form
        return render(request, 'admin/send_response.html', context)

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path(
                'respond/<int:pk>',
                self.respond_feedback,
                name='respond-feedback',
            ),
        ]
        return urls + custom_urls

    def respond_action(self, obj):
        return format_html(
            '<a class="button" href="{}">Respond</a>',
            reverse('admin:respond-feedback', args=[obj.id])
        )

    respond_action.short_description = 'Respond'


admin.site.register(Support, SupportAdmin)
admin.site.register(Unit)
admin.site.register(Booking)
admin.site.register(Devices)
admin.site.site_header = "BNB Tools"

from pyexpat import model
from django.db import models

class Support(models.Model):
    user = models.ForeignKey('users.User', on_delete=models.CASCADE)
    email = models.CharField(max_length=100)
    message = models.CharField(max_length=500)


class Unit(models.Model):
    user = models.ForeignKey('users.User', on_delete=models.CASCADE)
    name = models.CharField(max_length=50)
    number = models.IntegerField(blank=True, null=True)
    address = models.CharField(max_length=200, blank=True, null=True)
    city = models.CharField(max_length=50, blank=True, null=True)
    zip_code = models.CharField(max_length=10, blank=True, null=True)
    country = models.CharField(max_length=20, blank=True, null=True)
    image = models.ImageField(blank=True, null=True)
    st_location_id = models.CharField(
        max_length=255,
        blank=True,
        null=True
    )

class DeviceType(models.TextChoices):
    HEATER = 'HEATER', 'Heater'
    SMARTLOCK = 'SMARTLOCK', 'Smart Lock'
    SMARTOUTLET = 'SMARTOUTLET', 'Smart Outlet'
    SMARTLIGHT = 'SMARTLIGHT', 'Smart Light'
    FAN = 'FAN', 'Fan'
    SHUTTERS = 'SHUTTERS', 'Shutters'
    WATERHEATER = 'WATERHEATER', 'Water Heater'
    SMOKEDETECTOR = 'SMOKEDETECTOR', 'Smoke Detector'
    SOUNDSYSTEM = 'SOUNDSYSTEM', 'Sound System'
    GATE = 'GATE', 'Gate'
    VACUUM = 'VACUUM', 'Vacuum'
    SPRINKLER = 'SPRINKLER', 'Sprinkler'

class Devices(models.Model):
    unit = models.ForeignKey(Unit, on_delete=models.CASCADE)
    name = models.CharField(max_length=50, null=True, blank=True)
    device_type = models.CharField(
        choices=DeviceType.choices,
        max_length=50,
        null=True,
        blank=True
    )
    location = models.CharField(max_length=50, null=True, blank=True)
    provider = models.CharField(
        max_length=50,
        null=True,
        default=True
    )
    component_id = models.CharField(
        max_length=50,
        null=True,
        blank=True
    )
    device_id = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )
    status = models.JSONField(
        max_length=200,
        blank=True,
        null=True
    )
    capabilities = models.JSONField(
        max_length=200,
        blank=True,
        null=True
    )

    def is_connected(self):
        if self.device_id == None:
            return False
        else:
            return True


class Heater(Devices):
    mode = models.CharField(max_length=50, blank=True, null=True)
    temperature = models.IntegerField(blank=True, null=True)

class SmartLock(Devices):
    lock = models.CharField(max_length=50, blank=True, null=True)
    code = models.IntegerField(blank=True, null=True)

class SmartLight(Devices):
    switch = models.CharField(max_length=50, blank=True, null=True)
    level = models.IntegerField(blank=True, null=True)

class SmartOutlet(Devices):
    switch = models.CharField(max_length=50, blank=True, null=True)

class Fan(Devices):
    switch = models.CharField(max_length=50, blank=True, null=True)
    level = models.IntegerField(blank=True, null=True)

class Shutters(Devices):
    windowShade = models.CharField(max_length=50, blank=True, null=True)
    level = models.IntegerField(blank=True, null=True)

class WaterHeater(Devices):
    switch = models.CharField(max_length=50, blank=True, null=True)
    temperature = models.IntegerField(blank=True, null=True)

class SmokeDetector(Devices):
    smoke = models.CharField(max_length=50, blank=True, null=True)
    carbonMonoxide = models.CharField(max_length=50, blank=True, null=True)
    push_notifications_enabled = models.BooleanField(blank=True, null=True)

class SoundSystem(Devices):
    switch = models.CharField(max_length=50, blank=True, null=True)
    volume = models.IntegerField(blank=True, null=True)
    mute = models.CharField(max_length=50, blank=True, null=True)

class Gate(Devices):
    lock = models.BooleanField(blank=True, null=True)
    code = models.IntegerField(blank=True, null=True)

class Vacuum(Devices):
    switch = models.CharField(max_length=50, blank=True, null=True)
    cleaningStatus = models.CharField(max_length=50, blank=True, null=True)

class Sprinkler(Devices):
    valve = models.CharField(max_length=50, blank=True, null=True)
    delay = models.IntegerField(blank=True, null=True)


class Booking(models.Model):
    user = models.ForeignKey('users.User', on_delete=models.CASCADE)
    unit = models.ForeignKey(Unit, on_delete=models.CASCADE)
    guest_name = models.CharField(max_length=50)
    guest_contact = models.CharField(max_length=20)
    arrival = models.DateTimeField()
    departure = models.DateTimeField()


class BookingDevices(models.Model):
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE)
    device = models.ForeignKey(Devices, on_delete=models.CASCADE)

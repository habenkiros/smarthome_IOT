class Commands:
    TOGGLE_ON = {
        "component": "main",
        "capability": "switch",
        "command": "on"
    }
    TOGGLE_OFF = {
        "component": "main",
        "capability": "switch",
        "command": "off"
    }
    SET_HEAT_TEMPERATURE = {
        "component": "main",
        "capability": "thermostat",
        "command": "setHeatingSetpoint",
        "arguments": [{
            "value": 'temperature',
            "unit": 'unit'
        }]
    }
    SET_COOL_TEMPERATURE = {
        "component": "main",
        "capability": "thermostat",
        "command": "setCoolingSetpoint",
        "arguments": [{
            "value": 'temperature',
            "unit": 'unit'
        }]
    }
    TOGGLE_HEAT = {
        "component": "main",
        "capability": "thermostat",
        "command": "setThermostatMode",
        "arguments": [
            "heat"
        ]
    }
    TOGGLE_COOL = {
        "component": "main",
        "capability": "thermostat",
        "command": "setThermostatMode",
        "arguments": [
            "cool"
        ]
    }
    TOGGLE_ECO = {
        "component": "main",
        "capability": "thermostat",
        "command": "setThermostatMode",
        "arguments": [
            "eco"
        ]
    }
    TOGGLE_FAN_ONLY = {
        "component": "main",
        "capability": "thermostat",
        "command": "setThermostatMode",
        "arguments": [
            "fanonly"
        ]
    }
    TOGGLE_DRY = {
        "component": "main",
        "capability": "thermostat",
        "command": "setThermostatMode",
        "arguments": [
            "dry"
        ]
    }
    LOCK = {
        "component": "main",
        "capability": "lock",
        "command": "lock",
    }
    UNLOCK = {
        "component": "main",
        "capability": "lock",
        "command": "unlock",
    }
    SET_CODE = {
        "component": "main",
        "capability": "lockCodes",
        "command": "setCode",
        "arguments": [
            {
                "code": 'code',
                "name": 'name'
            }
        ]
    }
    SET_BRIGHTNESS = {
        "component": "main",
        "capability": "brightness",
        "command": "setBrightness",
        "arguments": [
            'brightness'
        ]
    }
    SET_SPEED = {
        "component": "main",
        "capability": "brightness",
        "command": "setBrightness",
        "arguments": [
            'speed'
        ]
    }
    TOGGLE_OPEN = {
        "component": "main",
        "capability": "windowShade",
        "command": "open"
    }
    TOGGLE_CLOSE = {
        "component": "main",
        "capability": "windowShade",
        "command": "close"
    }
    SET_LEVEL = {
        "component":"main",
        "capability":"windowShade",
        "command":"setLevel",
        "arguments": [
            'level'
        ]
    }
    SET_WATER_TEMPERATURE = {
        "component": "main",
        "capability": "thermostat",
        "command": "setTemperature",
        "arguments": [{
            "value": 'temperature',
            "unit": 'unit'
        }]
    }
    TOGGLE_NOTIFICATIONS = ''
    SET_VOLUME = {
        "component": "main",
        "capability": "volume",
        "command": "setVolume",
        "arguments": [
            'volume'
        ]
    }
    MUTE = {
        "component": "main",
        "capability": "audioMute",
        "command": "mute"
    }
    UNMUTE = {
        "component": "main",
        "capability": "audioMute",
        "command": "unmute"
    }
    DOCK = {
        "component": "main", 
        "capability": "dock"
    }
    RUN_CYCLE = {
        "component": "main",
        "capability": "cleaning",
        "command": "start"
    }
    SET_TIMER = ''
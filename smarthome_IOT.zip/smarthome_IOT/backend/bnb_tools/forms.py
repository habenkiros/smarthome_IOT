from django import forms

class ResponseForm(forms.Form):
    message = forms.CharField(widget=forms.Textarea(attrs={"rows":5, "cols":20}),max_length=255)
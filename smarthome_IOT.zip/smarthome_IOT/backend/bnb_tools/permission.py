from rest_framework import permissions

class UnitOwnerAndAuthenticated(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        # Check if the user is authenticated
        if not request.user.is_authenticated:
            return False

        # admins have access
        if request.user.is_staff:
            return True

        # Check if the user making the request is the owner of the object
        return obj.user == request.user


class IsOwnerAndAuthenticated(permissions.BasePermission):
    """
    Custom permission to only allow owners of an object to access it, and only if they are authenticated.
    """
    def has_object_permission(self, request, view, obj):
        # Check if the user is authenticated
        if not request.user.is_authenticated:
            return False

        # admins have access
        if request.user.is_staff:
            return True

        # Check if the user making the request is the owner of the object
        return obj.unit.user == request.user
from django.apps import AppConfig


class BnbToolsConfig(AppConfig):
    name = 'bnb_tools'

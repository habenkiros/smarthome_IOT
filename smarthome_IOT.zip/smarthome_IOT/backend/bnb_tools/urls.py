from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import (
    UserViewSet,
    AppleLogin,
    BookingViewSet,
    DevicesViewSet,
    GoogleLogin,
    SupportViewset,
    LogoutAPIView,
    UnitViewSet,
    FacebookLogin,
    # HeaterDeviceViewSet,
    # FanDeviceViewSet,
    # SmartLightDeviceViewSet,
    # SmartLockDeviceViewSet,
    # ShuttersDeviceViewSet,
    # WaterHeaterDeviceViewSet,
    # SmokeDetectorDeviceViewSet,
    # SoundSystemDeviceViewSet,
    # GateDeviceViewSet,
    # VacuumDeviceViewSet,
    # SprinklerDeviceViewSet
)
router = DefaultRouter()

router.register(r'users',UserViewSet,basename="users")
router.register(r'support',SupportViewset,basename="support")
router.register(r'unit',UnitViewSet,basename="unit")
router.register(r'devices',DevicesViewSet,basename="devices")
router.register(r'booking',BookingViewSet,basename="booking")


# router.register(r'heater',HeaterDeviceViewSet,basename="heater")
# router.register(r'fan',FanDeviceViewSet,basename="fan")
# router.register(r'smart_lock', SmartLockDeviceViewSet, basename="smart_lock")
# router.register(r'smart_light', SmartLightDeviceViewSet, basename="smart_light")
# router.register(r'shutters', ShuttersDeviceViewSet, basename="shutters")
# router.register(r'water_heater', WaterHeaterDeviceViewSet, basename="water_heater")
# router.register(r'smoke_detector', SmokeDetectorDeviceViewSet, basename="smoke_detector")
# router.register(r'sound_system', SoundSystemDeviceViewSet, basename="sound-system")
# router.register(r'gate', GateDeviceViewSet, basename="gate")
# router.register(r'vacuum', VacuumDeviceViewSet, basename="vacuum")
# router.register(r'sprinkler', SprinklerDeviceViewSet, basename="sprinkler")


urlpatterns = [
    path("",include(router.urls)),
    path('password_reset/', include('django_rest_passwordreset.urls', namespace='password_reset')),
    path(r'logout/',LogoutAPIView.as_view()),
    path('auth/facebook/', FacebookLogin.as_view(), name='fb_login'),
    path('auth/google/', GoogleLogin.as_view(), name='google_login'),
    path('auth/apple/', AppleLogin.as_view(), name='apple_login'),
    path("sms/", include("twilio_sms.urls")),
    path("subscriptions/", include("subscriptions.urls"))
]

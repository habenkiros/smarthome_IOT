from django.contrib.auth import get_user_model
from django.http import HttpRequest
from django.utils.translation import gettext_lazy as _
from allauth.account import app_settings as allauth_settings
from allauth.account.forms import ResetPasswordForm
from allauth.utils import email_address_exists, generate_unique_username
from allauth.account.adapter import get_adapter
from allauth.account.utils import setup_user_email
from rest_framework import serializers
from rest_auth.serializers import PasswordResetSerializer
from django.conf import settings
import random
from subscriptions.models import Plan
from rest_auth.models import TokenModel
from rest_auth.utils import import_callable
from rest_auth.serializers import UserDetailsSerializer as DefaultUserDetailsSerializer
from datetime import date
from dateutil.relativedelta import relativedelta
import logging
import dj_rest_auth.serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.views import TokenObtainPairView

from subscriptions.functions import sdk
stripe_sdk = sdk(settings.STRIPE_SECRET_KEY)
User = get_user_model()


class SignupSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'email', 'name', 'password', 'address',
                  'city', 'state', 'zip_code', 'country', 'photo']
        extra_kwargs = {
            'password': {
                'write_only': True,
                'style': {
                    'input_type': 'password'
                }
            },
            'email': {
                'required': True,
                'allow_blank': False,
            }
        }

    def _get_request(self):
        request = self.context.get('request')
        if request and not isinstance(request, HttpRequest) and hasattr(request, '_request'):
            request = request._request
        return request

    def validate_email(self, email):
        email = get_adapter().clean_email(email)
        if allauth_settings.UNIQUE_EMAIL:
            if email and email_address_exists(email):
                raise serializers.ValidationError(
                    _("A user is already registered with this e-mail address."))
        return email

    def create(self, validated_data):
        user = User(
            email=validated_data.get('email'),
            name=validated_data.get('name'),
            username=generate_unique_username([
                validated_data.get('name'),
                validated_data.get('email'),
                'user'
            ]),
            address=validated_data.get('address'),
            city=validated_data.get('city'),
            state=validated_data.get('state'),
            zip_code=validated_data.get('zip_code'),
            country=validated_data.get('country')

        )
        user.set_password(validated_data.get('password'))

        stripe_customer = stripe_sdk.create_customer()
        user.stripe_id = stripe_customer.id

        trial_end_timestap = (
            date.today() + relativedelta(months=+1)).strftime("%s")

        # Random shuffling plans
        plans = list(Plan.objects.all())
        plan = random.choice(plans)

        subscription = stripe_sdk.subscribe(
            customer_id=stripe_customer.id,
            plan_name=plan.name,
            price_id=plan.monthly_price_id,
            trial_ends=trial_end_timestap
        )
        user.subscription_id = subscription.id
        user.status = subscription.status
        user.save()

        request = self._get_request()
        setup_user_email(request, user, [])
        return user

    def save(self, request=None):
        """rest_auth passes request so we must override to accept it"""
        return super().save()


class LoginSerializer(dj_rest_auth.serializers.LoginSerializer):
    email = serializers.CharField(required=False, allow_blank=True)

    def _validate_username_email(self, username, email, password):
        if not username and not email:
            msg = _('Must include either "username" or "email" and "password".')
            raise serializers.ValidationError(msg)
        if User.objects.filter(email=email).exists():
            user = self.authenticate(email=email, password=password)
        else:
            user = self.authenticate(username=username, password=password)
        return user
    
class UserSerializer(serializers.ModelSerializer):
    is_provider_connected = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = User
        exclude = [
            'stripe_id',
            'st_token',
            'password',
            'user_permissions',
            'groups',
            'is_superuser',
            'is_staff'
        ]

    def get_is_provider_connected(self, user):
        return user.is_provider_connected()


class PasswordSerializer(PasswordResetSerializer):
    """Custom serializer for rest_auth to solve reset password error"""
    password_reset_form_class = ResetPasswordForm


rest_auth_serializers = getattr(settings, 'REST_AUTH_SERIALIZERS', {})
UserDetailsSerializer = import_callable(
    rest_auth_serializers.get(
        'USER_DETAILS_SERIALIZER', DefaultUserDetailsSerializer)
)

class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)

        # Add custom claims
        token['user'] = UserDetailsSerializer(instance=user).data

        return token
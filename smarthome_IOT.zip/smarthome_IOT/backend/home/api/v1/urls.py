from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt import views as jwt_views

from home.api.v1.viewsets import (
    SignupViewSet,
    # LoginViewSet,
    CustomTokenObtainPairView
)

router = DefaultRouter()
router.register("signup", SignupViewSet, basename="signup")
# router.register("login", LoginViewSet, basename="login")


urlpatterns = [
    path("", include(router.urls)),
    # path('login/', jwt_views.TokenObtainPairView.as_view(), name='login'),
    path('login/', CustomTokenObtainPairView.as_view(), name='login'),
]

from django.contrib import admin
from django.contrib.auth import admin as auth_admin
from django.contrib.auth import get_user_model

from users.forms import UserChangeForm, UserCreationForm

User = get_user_model()


def flag_user(modelAdmin, request, queryset):
    queryset.update(flagged=True)


flag_user.description = "Flag User"


@admin.register(User)
class UserAdmin(auth_admin.UserAdmin):

    def get_queryset(self, request):
        return User.objects.filter(is_staff=False, is_superuser=False)

    form = UserChangeForm
    add_form = UserCreationForm
    fieldsets = (("User", {"fields": ("name", "address", "city", "state", "zip_code", "country", "photo",
                 "flagged", "stripe_id", "subscription_id", "active_plan")}),) + auth_admin.UserAdmin.fieldsets
    list_display = ["username", "name", "email"]
    search_fields = ["name"]

    actions = [flag_user]

from django.contrib.auth.models import AbstractUser
from django.db import models
from django.urls import reverse
from django.utils.translation import gettext_lazy as _
import datetime


class User(AbstractUser):
    # WARNING!
    """
    Some officially supported features of Crowdbotics Dashboard depend on the initial
    state of this User model (Such as the creation of superusers using the CLI
    or password reset in the dashboard). Changing, extending, or modifying this model
    may lead to unexpected bugs and or behaviors in the automated flows provided
    by Crowdbotics. Change it at your own risk.


    This model represents the User instance of the system, login system and
    everything that relates with an `User` is represented by this model.
    """

    # First Name and Last Name do not cover name patterns
    # around the globe.
    name = models.CharField(_("Name of User"), blank=True,
                            null=True, max_length=255)
    address = models.CharField(blank=True, max_length=100, null=True)
    city = models.CharField(blank=True, max_length=20, null=True)
    state = models.CharField(blank=True, max_length=20, null=True)
    zip_code = models.CharField(blank=True, max_length=20, null=True)
    country = models.CharField(blank=True, max_length=20, null=True)
    photo = models.ImageField(blank=True, null=True)
    st_token = models.CharField(blank=True, max_length=200, null=True)
    flagged = models.BooleanField(default=False)
    stripe_id = models.CharField(max_length=250, blank=True, null=True)
    subscription_id = models.CharField(max_length=250, blank=True, null=True)
    active_plan = models.ForeignKey(
        'subscriptions.Plan',
        on_delete=models.CASCADE,
        related_name='active_plan',
        null=True,
        blank=True
    )

    # trialing, active, unpaid, cancelled, incomplete
    status = models.CharField(max_length=250, default='trialing')

    def get_absolute_url(self):
        return reverse("users:detail", kwargs={"username": self.username})

    def is_provider_connected(self):
        if self.st_token != None:
            return True
        else:
            return False

from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import requests
import json
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view, permission_classes
from .sdk import SmartThings

token = '71fc6741-dca6-42e7-865c-9158bc1a3014'
ST = SmartThings(token)


@api_view(['POST'])
@permission_classes([AllowAny])
@csrf_exempt
def webhook(request):
    request_json = request.body.decode('utf8').replace("'", '"')
    response_data = json.loads(request_json)
    res = requests.get(response_data['confirmationData']['confirmationUrl'])
    return JsonResponse(data={"confirmation url verified successfully"}, status=200, safe=False)


def test_sdk(request):
    device_id = '9556f297-f329-41ff-a147-4b4b6cd67613'
    devices = ST.get_device_list()
    device = ST.get_device(device_id)
    status = ST.get_status(device_id)
    cmd = ST.execute_command(device_id, 'main', 'switch', 'on')
    # return JsonResponse(data=status, status=200, safe=False)

    return JsonResponse(data={"devices": devices, "device": device, "status": status, "cmd": cmd},
                        status=200, safe=False)

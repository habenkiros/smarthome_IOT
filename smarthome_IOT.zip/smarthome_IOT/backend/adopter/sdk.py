import requests

SS_URL = "https://api.smartthings.com"


class SmartThings:
    def __init__(self, device_bearer_token):
        self.base_url = SS_URL
        self.device_bearer_token = device_bearer_token
        # self.device_id = device_id
        self.session = requests.Session()
        self.session.headers.update(self.__headers())

    def __headers(self, headers=None):
        if headers is None:
            headers = {'Accept': 'application/vnd.smartthings+json;v=1',
                       'Authorization': f'Bearer {self.device_bearer_token}'}
            return headers

    def reset_session(self):
        self.session = requests.Session()
        self.session.headers.update(self.__headers())

    def _get(self, path, params):
        res = self.session.get(path, params=params)
        if res.status_code == 200:
            return res.json()
        else:
            return None

    def _post(self, path, data):
        res = requests.post(path, json=data, headers=self.__headers())
        if res.status_code == 200 or res.status_code == 201:
            return {"status": "success", "message": res.text}
        else:
            resp = res.json()
            resp["status"] = "error"
            resp["status_code"] = res.status_code
            return resp

    def _delete(self, path, data = None):
        res = requests.delete(path, json=data, headers=self.__headers())
        if res.status_code == 200 or res.status_code == 201:
            return {"status": "success", "message": res.json()}
        else:
            resp = res.json()
            resp["status"] = "error"
            resp["status_code"] = res.status_code
            return resp

    def _put(self, path, data):
        res = requests.put(path, json=data, headers=self.__headers())
        if res.status_code == 200 or res.status_code == 201:
            return {"status": "success", "message": res.json()}
        else:
            resp = res.json()
            resp["status"] = "error"
            resp["status_code"] = res.status_code
            return resp

    # def get_url(self):
    #     # SSURL
    #     pass

    def get_location_list(self, params: dict = None):
        """
        Get a list of devices.
        :param params: Query parameters
        :return: Response
        """
        path = '/locations'
        return self._get(self.base_url + path, params)

    def get_device_list(self, params: dict = None):
        """
        Get a list of devices.
        :param params: Query parameters
        :return: Response
        """
        path = '/devices'
        return self._get(self.base_url + path, params)

    def get_device(self, device_id: str):
        """
        Get a Device's given description.
        :param device_id: Device ID
        :return: Response
        """
        path = f'/devices/{device_id}'
        return self._get(self.base_url + path, None)

    def delete_device(self, device_id: str):
        """
        Delete a Device with a given Device ID.
        :param device_id: Device ID
        :return: Response
        """
        path = f'/devices/{device_id}'
        return self._delete(self.base_url + path, None)

    def update_device(self, device_id: str, data: dict):
        """
        Update the properties of a device.
        :param device_id: Device ID
        :param data: Data to update
        :return: Response
        """
        path = f'/devices/{device_id}'
        return self._put(self.base_url + path, data)

    def execute_command(self, device_id: str, component_id: str, capability: str, command: str, args: list = None):
        """
        Execute a specified command on a Device.
        :param device_id: Device ID
        :param component_id: Component ID
        :param capability: Capability
        :param command: Command
        :param args: Arguments
        :return: Response
        """
        path = f'/devices/{device_id}/commands'
        data = [{"component": component_id, "capability": capability, "command": command,
        "arguments": args}]
        return self._post(self.base_url + path, data)

    def execute_automation(self, trigger_type: str, trigger_args: str, device_id: str, component_id: str, capability: str, command: str, args: list = None):
        """
        Execute a command with added logic.
        :param device_id: Device ID
        :param component_id: Component ID
        :param capability: Capability
        :param command: Command
        :param args: Arguments
        :return: Response
        """
        path = f'/v1/automations'
        data = [{"component": component_id, "capability": capability, "command": command,
        "arguments": args, "trigger_type": trigger_type, "trigger_args": trigger_args}]

        return self._post(self.base_url + path, data)
    
    def delete_automation(self, automation_id):
        """
        Execute a command with added logic.
        :param device_id: Device ID
        :param component_id: Component ID
        :param capability: Capability
        :param command: Command
        :param args: Arguments
        :return: Response
        """
        path = f'/v1/automations/{automation_id}'
        
        return self._delete(self.base_url + path)

    def get_status(self, device_id: str):
        """
        Get the current status of all of a Device component's attributes.
        :param device_id: Device ID
        :return: Response
        """
        path = f'/devices/{device_id}/status'
        return self._get(self.base_url + path, None)

    def create_location(self, name:str):
        """
        Create Location in smart things app
        :param name: Name of location
        :return: locationId
        """

        path = f'/locations'
        data = {
            "name": name,
            "countryCode": 'USA'
        }
        return self._post(self.base_url+path, data)
    
    def create_device_in_location(self, label:str, location_id:str, device_type_id:str):
        """
        Create Location in smart things app
        :param name: Name of location
        :return: locationId
        """

        path = f'/devices'
        data = {
            "label": label,
            "locationId": location_id,
            "deviceTypeId": device_type_id
        }
        return self._post(self.base_url+path, data)
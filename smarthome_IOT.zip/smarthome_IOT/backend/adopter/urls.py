from django.urls import path
from .views import webhook, test_sdk

urlpatterns = [
    path("webhook/", webhook, name="webhook"),
    path("test/", test_sdk, name="test_sdk"),
]

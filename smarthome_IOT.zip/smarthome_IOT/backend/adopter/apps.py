from django.apps import AppConfig


class AdopterConfig(AppConfig):
    name = 'adopter'

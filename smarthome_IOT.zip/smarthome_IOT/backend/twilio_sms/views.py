import logging
from django.shortcuts import render
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

import json
from twilio_sms.functions import (
    twilio_send_sms,
    twilio_send_notification
)


class TwilioAPIView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, format=None):
        try:
            to = request.data.get('to')
            sms_data = twilio_send_sms(to=to, body="BNB Tool Demo ")
            logging.info(sms_data)
            return Response(
                status=status.HTTP_200_OK,
                data="SMS Sent"
            )

        except Exception as e:
            logging.error(e)

            return Response(
                status=status.HTTP_200_OK,
                data="Error"
            )


class TwilioNotificationAPIView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, format=None):
        try:
            notification_data = twilio_send_notification()
            logging.info(notification_data)
            return Response(
                status=status.HTTP_200_OK,
                data="Notification Sent"
            )
        except:
            return Response(
                status=status.HTTP_200_OK,
                data="Error Sending"
            )

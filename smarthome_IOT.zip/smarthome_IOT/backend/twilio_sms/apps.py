from django.apps import AppConfig


class TwilioSmsConfig(AppConfig):
    name = 'twilio_sms'

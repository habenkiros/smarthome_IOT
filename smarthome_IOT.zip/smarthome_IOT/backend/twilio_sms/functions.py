from twilio.rest import Client
from django.conf import settings


def twilio_send_sms(to, body):
    account_sid = settings.TWILIO_SID
    auth_token = settings.TWILIO_AUTH_TOKEN

    client = Client(account_sid, auth_token)

    message = client.messages.create(
        body=body,
        from_=settings.TWILIO_NUMBER,
        to=to
    )
    return(message)


def twilio_send_notification():
    account_sid = settings.TWILIO_SID
    auth_token = settings.TWILIO_AUTH_TOKEN

    client = Client(account_sid, auth_token)

    notification = client.notify \
        .services('IS6439a632ee510f02fd8d125ad303977e') \
        .notifications \
        .create(
            body='Hello from BN Tool',
            identity=['00000001'],
            tag=['preferred_device']
        )

    print(notification.sid)

    return(notification)

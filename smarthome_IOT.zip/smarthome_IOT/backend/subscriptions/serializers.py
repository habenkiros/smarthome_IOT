from rest_framework import serializers
from .models import PaymentMethod, Plan

from .functions import sdk
from django.conf import settings

stripe_sdk = sdk(settings.STRIPE_SECRET_KEY)


class PlanSerializer(serializers.ModelSerializer):
    class Meta:
        model = Plan
        exclude = [
            'min_units',
            'max_units',
            'stripe_id',
            'monthly_price_id',
            'yearly_price_id'
        ]


class PaymentMethodSerializer(serializers.ModelSerializer):
    token = serializers.CharField(write_only=True)

    class Meta:
        model = PaymentMethod
        fields = '__all__'
        extra_kwargs = {
            'stripe_id': {
                'read_only': True
            },
            'user': {
                'read_only': True
            },
            'exp_month': {
                'read_only': True
            },
            'exp_year': {
                'read_only': True
            },
            'apple_pay': {
                'read_only': True
            },
            'funding': {
                'read_only': True
            },
            'last4': {
                'read_only': True
            }
        }

    def create(self, validated_data):
        user = self.context['request'].user
        payment_method = stripe_sdk.add_payment_method(
            customer_id=user.stripe_id,
            type='card',
            token=validated_data.get('token')
        )
        if payment_method.card.wallet:
            apple_pay = payment_method.card.wallet.apple_pay
        else:
            apple_pay = None

        return PaymentMethod.objects.create(
            user=user,
            stripe_id=payment_method.id,
            exp_month=payment_method.card.exp_month,
            exp_year=payment_method.card.exp_year,
            last4=payment_method.card.last4,
            apple_pay=apple_pay,
            funding=payment_method.card.funding
        )

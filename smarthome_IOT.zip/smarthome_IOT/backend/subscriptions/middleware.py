from django.core.exceptions import PermissionDenied
import logging
NOT_WHITELISTED_URLS = [
    # "unit",
    "devices",
    "bookings",
]

WHITE_LIST_STATUS = [
    "active",
    "trialing"
]


class SubscriptionMiddleware(object):
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        # if request.user.is_authenticated:
        #     user = request.user
        #     if request.path.split('/')[2] in NOT_WHITELISTED_URLS and user.status not in WHITE_LIST_STATUS:
        #         raise PermissionDenied(user.status)
        return response

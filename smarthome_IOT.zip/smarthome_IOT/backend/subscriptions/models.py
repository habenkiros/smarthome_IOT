from django.db import models

# Create your models here.


class Plan(models.Model):
    name = models.CharField(max_length=250)
    min_units = models.IntegerField()
    max_units = models.IntegerField()
    monthly_price = models.IntegerField()
    yearly_discount = models.IntegerField()
    stripe_id = models.CharField(max_length=250, blank=True, null=True)
    monthly_price_id = models.CharField(max_length=250, blank=True, null=True)
    yearly_price_id = models.CharField(max_length=250, blank=True, null=True)


class PaymentMethod(models.Model):
    user = models.ForeignKey(
        'users.User',
        on_delete=models.CASCADE,
        related_name='payment_method')

    stripe_id = models.CharField(max_length=250)
    funding = models.CharField(max_length=250, null=True, blank=True)
    exp_month = models.IntegerField(null=True, blank=True)
    exp_year = models.IntegerField(null=True, blank=True)
    last4 = models.CharField(max_length=4, null=True, blank=True)
    apple_pay = models.CharField(max_length=255, blank=True, null=True)

default_app_config = 'subscriptions.apps.SubscriptionsConfig'

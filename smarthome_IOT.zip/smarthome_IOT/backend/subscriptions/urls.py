from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import PaymentMethodViewSet, PlanViewSet, CancelSubscriptionAPIView, UpdateSubscriptionAPIView
router = DefaultRouter()

router.register(r'payment_method', PaymentMethodViewSet,
                basename="payment_method")
router.register(r'plans', PlanViewSet, basename="plans")

urlpatterns = [
    path("", include(router.urls)),
    path(r"cancel", CancelSubscriptionAPIView.as_view()),
    path(r"update", UpdateSubscriptionAPIView.as_view())
]

from .models import Plan
from django.db.models.signals import post_save
from django.dispatch import receiver
from .functions import sdk, cal_yearly_price
from django.conf import settings

stripe_sdk = sdk(settings.STRIPE_SECRET_KEY)


@receiver(post_save, sender=Plan)
def create_plans(sender, instance, created, **kwargs):
    if created:
        product, price_monthly, price_yearly = stripe_sdk.create_product(
            name=instance.name,
            unit_amount=instance.monthly_price,
            yearly_discount=instance.yearly_discount
        )

        Plan.objects.filter(
            id=instance.id
        ).update(
            stripe_id=product.id,
            monthly_price_id=price_monthly.id,
            yearly_price_id=price_yearly.id
        )
    else:
        monthly_price = stripe_sdk.create_price(
            product_id=instance.stripe_id,
            unit_amount=instance.monthly_price,
            interval='month'
        )

        # Updating yearly price data
        yearly_price = stripe_sdk.create_price(
            product_id=instance.stripe_id,
            unit_amount=cal_yearly_price(
                unit_amount=instance.monthly_price,
                yearly_discount=instance.yearly_discount
            ),
            interval='year'

        )

        Plan.objects.filter(id=instance.id).update(
            monthly_price_id=monthly_price.id,
            yearly_price_id=yearly_price.id
        )

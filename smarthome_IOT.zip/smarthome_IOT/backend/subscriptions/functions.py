import stripe
import logging


def cal_yearly_price(unit_amount: int, yearly_discount: int):
    return (int(unit_amount) * 12) * (1-(int(yearly_discount) / 100))


class sdk:
    def __init__(self, api_key):
        stripe.api_key = api_key

    def create_customer(self):
        return stripe.Customer.create()

    def create_price(self, product_id: str, unit_amount: int, interval: str):
        try:
            recurring_data_monthly = {
                "interval": interval,  # month, year
            }
            price_monthly = stripe.Price.create(
                product=product_id,
                unit_amount=int(unit_amount),
                currency='usd',
                recurring=recurring_data_monthly
            )
            return price_monthly
        except Exception as e:
            logging.error(e)
            return False

    def create_product(self, name: str, unit_amount: int, yearly_discount: int):
        product = stripe.Product.create(
            name=name
        )

        recurring_data_monthly = {
            "interval": 'month',  # month, year
        }

        recurring_data_yearly = {
            "interval": 'year',  # month, year
        }
        price_monthly = stripe.Price.create(
            product=product.id,
            unit_amount=int(unit_amount),
            currency='usd',
            recurring=recurring_data_monthly
        )
        calculated_yearly = cal_yearly_price(
            unit_amount=unit_amount,
            yearly_discount=yearly_discount)

        price_yearly = stripe.Price.create(
            product=product.id,
            unit_amount=int(calculated_yearly),
            currency='usd',
            recurring=recurring_data_yearly
        )
        return product, price_monthly, price_yearly

    def subscribe(self, customer_id: str, plan_name: str, price_id: str, trial_ends):
        # Create a product and get price data

        subscription = stripe.Subscription.create(
            customer=customer_id,
            items=[
                {
                    "price": price_id,
                    "quantity": 1

                },
            ],
            trial_end=trial_ends

        )
        return subscription

    def add_payment_method(self, type: str, customer_id: str, token: str):
        try:
            payment_method = stripe.PaymentMethod.create(
                type="card",
                card={
                    "number": "4242424242424242",
                    "exp_month": 11,
                    "exp_year": 2023,
                    "cvc": "314",
                },
            )

            return payment_method

        except Exception as e:
            logging.error(e)
            return None

    def delete_payment_method(self, _id: str):
        try:

            stripe.PaymentMethod.detach(
                _id,
            )
            return True
        except Exception as e:

            return False

    def update_subscription(self, _id: str, product_id: str, price_id: str):
        try:
            subscription = stripe.Subscription.retrieve(_id)

            stripe.Subscription.modify(
                subscription.id,
                proration_behavior='create_prorations',
                items=[{
                    'price': price_id
                }]
            )
            return True
        except Exception as e:
            logging.error(e)
            return False

    def cancel_subscription(self, _id: str):
        try:
            stripe.Subscription.delete(
                _id,
            )
            return True
        except Exception as e:
            logging.error(e)
            return False

    def update_price(self, _id: str, price: int):
        try:
            stripe.Price.modify(
                _id,
                unit_amount=price,
            )
            return True
        except Exception as e:
            logging.error(e)
            return False

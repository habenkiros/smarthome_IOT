from django.conf import settings
from django.http import Http404
from rest_framework import status, viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from django.contrib.auth import get_user_model
import logging

# Create your views here.
from .functions import sdk
from .models import PaymentMethod, Plan
from .serializers import PaymentMethodSerializer, PlanSerializer

stripe_sdk = sdk(settings.STRIPE_SECRET_KEY)
User = get_user_model()


class PaymentMethodViewSet(ModelViewSet):
    permission_classes = (IsAuthenticated, )
    serializer_class = PaymentMethodSerializer
    queryset = PaymentMethod.objects.all()
    http_methods = ['post', 'get']

    def list(self, request, *args, **kwargs):
        user = request.user
        payment_methods = self.queryset.filter(user=user)
        return Response(self.serializer_class(payment_methods, many=True).data)

    def get(self, request, *args, **kwargs):
        user = request.user
        payment_methods = self.queryset.filter(user=user)
        return Response(self.serializer_class(payment_methods))

    def destroy(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            stat = stripe_sdk.delete_payment_method(instance.stripe_id)
            if(stat == True):
                self.perform_destroy(instance)
            else:
                Response(status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except Http404:
            pass
        return Response(status=status.HTTP_204_NO_CONTENT)


class PlanViewSet(ModelViewSet):
    permission_classes = (IsAuthenticated, )
    serializer_class = PlanSerializer
    queryset = Plan.objects.all()
    http_methods = ['get']


class CancelSubscriptionAPIView(APIView):
    def post(self, request):
        permission_classes = [IsAuthenticated, ]

        user = User.objects.get(id=request.user.id)
        _status = stripe_sdk.cancel_subscription(user.subscription_id)
        if _status == True:
            user.subscription_id = None
            user.active_plan = None
            user.save()

            return Response({
                "message": "Unsubscribed Successfullly"
            }, status=status.HTTP_200_OK)
        else:
            return Response({
                "message": "Error unsubscribing"
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class UpdateSubscriptionAPIView(APIView):
    def post(self, request):
        permission_classes = [IsAuthenticated, ]

        try:
            user = User.objects.get(id=request.user.id)
            plan_id = request.data.get('plan_id')
            plan = Plan.objects.get(id=plan_id)
            interval = request.data.get('interval')  # year or month

            if interval == 'year':
                plan_price_id = plan.yearly_price_id
            elif interval == 'month':
                plan_price_id = plan.monthly_price_id
            else:
                return Response(
                    {
                        "message": "Invalid Interval"
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )

            _status = stripe_sdk.update_subscription(
                _id=user.subscription_id,
                product_id=plan.stripe_id,
                price_id=plan_price_id
            )
            if _status == True:
                return Response({
                    "message": "Subscription Updated"
                }, status=status.HTTP_200_OK)
            else:
                return Response(
                    {
                        "message": "Error updating subscription"
                    },
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
        except Exception as e:
            logging.error(e)
            return Response(
                {
                    "message": "Error updating subscription"
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

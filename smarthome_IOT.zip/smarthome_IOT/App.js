import React, { useContext } from "react"
import { Provider } from "react-redux"
import { ThemeProvider } from "react-native-elements"
import { GlobalOptionsContext, theme } from "@options"
import { getStore } from "store"
import { GoogleSignin } from "@react-native-google-signin/google-signin"
import Toast, { ErrorToast, SuccessToast } from "react-native-toast-message"
import { StripeProvider } from "@stripe/stripe-react-native"

GoogleSignin.configure({
  iosClientId:
    "931745599514-baj00s5aql3d5geipdt94r805vcf14pn.apps.googleusercontent.com",
  forceCodeForRefreshToken: false,
  webClientId:
    "931745599514-hgj8pg4omns3mv75rudp86a2kk41c0on.apps.googleusercontent.com"
})

import Navigation from "navigation"
import { typography } from "utils"

const App = () => {
  const global = useContext(GlobalOptionsContext)
  const store = getStore(global)

  return (
    <StripeProvider publishableKey={"pk_test_51M2nVND4zLc4zs3SpBj8AfHEqnTmQfodmXJGak5vrBhJ65WtmDivgFs5lXwidDBcj9sv5PRBdYmIYf2FN9bLOjv700dM9Vagx0"}>
      <Provider store={store}>
        <ThemeProvider theme={theme}>
          <Navigation />
          <Toast config={toastConfig} />
        </ThemeProvider>
      </Provider>
    </StripeProvider>
  )
}

export default App

const toastConfig = {
  /*
    Overwrite 'success' type,
    by modifying the existing `BaseToast` component
  */
  success: props => (
    <SuccessToast
      {...props}
      text1Style={{
        fontFamily: typography.medium_600
      }}
      text2Style={{
        fontFamily: typography.regular_400
      }}
    />
  ),
  /*
    Overwrite 'error' type,
    by modifying the existing `ErrorToast` component
  */
  error: props => (
    <ErrorToast
      {...props}
      text1Style={{
        fontFamily: typography.medium_600
      }}
      text2Style={{
        fontFamily: typography.regular_400
      }}
    />
  )
}
